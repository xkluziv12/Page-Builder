# MARK'S RULES, Replit project handoff

## Purpose

This packet contains Mark's universal operating rules for a new Replit
project. It is a rules handoff, not an application source-code package.

`MARKS-RULES.md` is the one canonical document to give a new Replit chat.
This packet intentionally does not include older competing rule copies.
`DEEPSEEK-CLI-SETUP.md` is a separate procedure for installing and using the
default secondary DeepSeek worker through the Claude Code CLI. It is not a
second rules source.

## Why this packet was updated

Mark has used Replit Agent, Claude Code, DeepSeek, Grok, Canvas, direct image
APIs, and multiple site-building workflows across projects. Earlier projects
developed overlapping rule files, stale model instructions, different provider
assumptions, and old handoff copies. That caused chats to disagree about which
rules were active, which settings could be changed, and which model or
credential was actually being used.

This packet fixes that by:

- keeping one current universal rules document;
- keeping project facts and important original settings local;
- making Claude Sonnet the primary implementation worker;
- making DeepSeek the standard lower-cost secondary setup;
- keeping Claude OAuth and DeepSeek API authentication separate;
- requiring real model, tool, credential, and validation checks;
- using bounded sessions instead of blindly carrying giant conversations;
- preserving important embedded behavior and platform settings;
- removing obsolete competing rules after adaptation;
- refusing destructive cleanup based only on an AI's guess.

You do not need Mark to explain this history again. Read every file in this
packet, apply the intent, adapt it to the actual project, and explain only a
real conflict.

The receiving Replit chat must adapt the rules to the actual project. Do not
paste them blindly, do not assume this project has the same tools, and do not
copy project-specific paths, secrets, GitHub settings, product language, or
CLI wrappers from another project.

## First action

Before doing any other work in the receiving project, read **every file in
this packet**. `MARKS-RULES.md` is the authority for principles,
`DEEPSEEK-CLI-SETUP.md` is the setup procedure, this README explains the
adaptation, and `PROJECT-LOCAL-TEMPLATE.md` identifies what belongs locally.
Then:

1. Read `MARKS-RULES.md` completely.
2. Treat the packet as the preferred common baseline, not a reason to break
   important existing behavior. Inspect original settings, embedded behavior,
   integrations, content, and platform constraints first.
3. Preserve what must remain, adapt the rest toward the shared rules, and
   explain meaningful conflicts instead of refusing broadly.
4. Reuse the packet's useful parts and follow them to the best of your ability.
5. Start installing and verifying DeepSeek immediately using
   `DEEPSEEK-CLI-SETUP.md` when the secure key is available. Do not wait for
   another prompt. If a real constraint blocks installation, record the exact
   reason and continue with the rest of the adaptation. Keep Claude OAuth
   unchanged.
6. Create or update that project's `replit.md` with a concise version of the
   applicable universal rules plus the project's actual stack, commands,
   protected paths, tools, and verified facts.
7. If Claude Code CLI is installed or will be used, create or update
   `CLAUDE.md` in Claude's actual working directory. It must stand alone and
   contain the project's real file map, hard boundaries, and verification
   commands.
8. Save the durable rules in the project's own memory system if one exists.
9. Remove obsolete universal-rule files, old Claude setup prompts, and
   superseded provider instructions after the new local documents are
   confirmed. Preserve important original settings and verified project facts.
10. Confirm the adaptation briefly, then continue with Mark's original request.

Do not paste this packet verbatim into `replit.md` or `CLAUDE.md`. Preserve the
substance in concise project-appropriate wording.

## What must remain universal

- Mark is a vibe coder. Use plain, concise, scannable language.
- Call him Mark, push back on bad assumptions, and flag uncertainty.
- Do not present partial work as complete.
- Claude Code CLI is the primary implementation worker when available.
- Replit Agent scopes, dispatches, supervises, and independently verifies.
- Claude defaults to Sonnet at medium effort. Stronger models require Mark's
  approval before switching.
- Never create, propose, or silently use a Replit-managed LLM integration or
  connector unless Mark approves that specific integration by name.
- Use Mark's own direct provider keys. OpenAI and Gemini may also be used for
  image generation when needed.
- Never ask Mark to paste secrets into chat or print secret values.
- Use bounded tasks, named sources of truth, explicit verification, and
  independent checks.
- Keep the rules flexible. Escalate real conflicts instead of guessing.
- Preserve important original settings and embedded behavior, but delete old
  competing universal-rule copies after adapting the current rules.
- Do not use em dashes in deliverables.

## What belongs only in the receiving project

The receiving chat must discover and document locally:

- Which CLIs and providers are actually available.
- Whether DeepSeek is installed through a verified wrapper, and its actual
  secret name and local path.
- The real runtime secret presence, checked without exposing values.
- The project's stack, paths, workflows, wrappers, and verification commands.
- Protected artifacts, production boundaries, GitHub settings, and deployment
  rules.
- Product facts and business copy.
- Any project-specific Grok or Claude recovery instructions.
- Whether commits or pushes are allowed, and under what approval rule.
- Whether any enforcement gate, hook, skill, or decision log actually exists.

## Conflict rule

If these rules conflict with an existing deliberate project policy, original
settings that are required for operation, a GitHub or deployment decision, a
provider restriction, product wording, or another out-of-scope decision,
preserve the important local behavior, adapt the shared rule as far as safely
possible, and ask Mark about the meaningful conflict. Do not silently choose a
side or refuse the entire ruleset.

## Intended result

The universal packet stays short and stable. Each project's `replit.md` and
`CLAUDE.md` become the adapted local operating layer. Update the universal
master only when a durable, general lesson applies across projects.

The first setup pass should finish with Claude OAuth still separate, DeepSeek
installed or explicitly blocked with evidence, old competing universal-rule
copies removed, important original settings preserved, and local project
instructions updated.