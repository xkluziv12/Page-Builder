# MARK'S RULES, Full Replit Operator Packet

## What this packet is

This is the expanded portable packet for running substantial Replit jobs with
Claude Code, DeepSeek, optional Grok support, page-building standards, image
requirements, SEO/GEO, schema, and URL architecture guidance.

## Read and apply in this order

1. `01-core-rules/MARKS-RULES.md` is the canonical universal operating contract.
2. `01-core-rules/PROJECT-LOCAL-TEMPLATE.md` explains what each receiving project
   must discover and write locally. Do not copy AVA-specific facts into a new
   project.
3. `02-runner-setup/DEEPSEEK-CLI-SETUP.md` applies only after the receiving
   project verifies its own CLI, secret name, wrapper path, and runtime.
4. For a new or rebuilt page, use
   `03-page-building/UNIVERSAL-MASTER-PAGE-BUILDER-SOURCE-OF-TRUTH-v1.4.txt`.
   It contains the complete sequential capability, source-recovery, research,
   build, imagery, SEO, GEO, schema, and final-verification phases.
5. Use the files in `04-specialized-templates/` only for the matching job:
   page construction, an existing-page SEO audit, schema generation, or hub/spoke
   URL planning. They are specialized templates, not replacements for the
   universal rules.
6. `05-optional-long-job-operator/GROK-PORTABLE-LONG-JOB-OPERATOR.md` is an
   optional long-running-job and Grok CLI addendum. Use it only when Grok is
   actually installed and approved for that project.

## P1-P4 and imagery coverage

The Universal Master Page Builder v1.4 includes:

- Phase -1: capability check and available-tool declaration.
- Phase 0: live-site-first source recovery, Wayback gap filling, source facts,
  confidence labels, and anti-fabrication rules.
- Phase 1: competitor, local/niche, E-E-A-T, keyword, section-depth, and image
  slot research.
- Phase 2: modular design/build, copy discipline, generated-image requirements,
  image acceptance, alt text, responsive rendering, and visual verification.
- Phase 3: title/meta, headings, internal links, image optimization, technical
  SEO, GEO, E-E-A-T, and local SEO.
- Phase 4: source-or-omit schema, FAQ validity, JSON-LD graph structure, and
  end-to-end verification.

The imagery rules are instructions for generating and validating images. This
portable packet intentionally does not include AVA's project-specific image
assets or business facts.

## Important exclusions

This packet intentionally excludes older competing copies, project-specific
`CLAUDE.md` and `replit.md` files, AVA source code, AVA image assets, and old
provider setup prompts that contain superseded assumptions. The receiving
project must adapt the universal rules to its actual tools and constraints.

Never paste secrets into these files or into chat. Never assume a provider,
CLI, path, model, integration, or workflow exists without verifying it in the
receiving project.
