# DeepSeek through Claude Code CLI

This is the standard secondary-worker setup guide. Begin this setup
immediately in a receiving project when the secure key is available. It uses Claude Code as the local CLI harness
and routes the selected model to DeepSeek's Anthropic-compatible API. It does
not install DeepSeek into a Claude account and it does not replace Claude OAuth.

## Before installing

1. Check whether Claude Code is already installed:

   ```bash
   claude --version
   ```

2. Confirm the DeepSeek secret exists through the secure secrets manager.
   Mark's current Replit secret is `Deepseek`, but secret names are
   case-sensitive and must be verified in each project.
3. Never print the secret, put it in source control, or paste it into chat.
4. Check whether a `deepseek` command or wrapper already exists. Do not
   overwrite an existing deliberate setup without inspecting it.

## Wrapper setup

Create a wrapper named `deepseek` in a directory on `PATH`, such as
`$HOME/.local/bin/deepseek`, or place it beside the existing Claude executable
when that directory is already on `PATH`. In the current Replit environment,
the verified location is:

```text
/home/runner/workspace/.config/npm/node_global/bin/deepseek
```

The wrapper should read the secret at runtime and delegate to the
already-installed `claude` executable:

```bash
#!/usr/bin/env bash
set -euo pipefail

: "${Deepseek:?Missing Replit secret: Deepseek}"
: "${CLAUDE_CODE_EFFORT_LEVEL:=medium}"

export ANTHROPIC_BASE_URL="https://api.deepseek.com/anthropic"
export ANTHROPIC_AUTH_TOKEN="$Deepseek"
export ANTHROPIC_MODEL="deepseek-v4-pro[1m]"
export ANTHROPIC_DEFAULT_OPUS_MODEL="deepseek-v4-pro[1m]"
export ANTHROPIC_DEFAULT_SONNET_MODEL="deepseek-v4-pro[1m]"
export ANTHROPIC_DEFAULT_HAIKU_MODEL="deepseek-v4-flash[1m]"
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

exec claude "$@"
```

Then make it executable and verify the command resolves. Do not overwrite an
existing deliberate wrapper without inspecting it first:

```bash
chmod 700 "$HOME/.local/bin/deepseek"
command -v deepseek
```

If the directory is not already on `PATH`, add it for the current shell:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

The exact wrapper location, secret name, and Claude binary location belong in
the receiving project's local `replit.md`. Do not copy another project's paths
blindly.

In this current AVA Replit environment, the wrapper is installed and verified
at the path above. Other projects must still check their own Claude path and
secret name rather than copying that status.

## Use DeepSeek

Run from the project directory:

```bash
cd /home/runner/workspace
CLAUDE_CODE_EFFORT_LEVEL=medium deepseek
```

For a bounded non-interactive task:

```bash
CLAUDE_CODE_EFFORT_LEVEL=medium deepseek -p \
  "Perform only the named task. Report files changed and verification output." \
  --model sonnet --effort medium
```

The `sonnet` alias is retained because the Claude Code harness maps it to the
DeepSeek default model through the wrapper. Verify the actual model in the
response or JSON envelope. Do not assume the alias proves the backend.

## Persistent sessions

Persistent continuation is available when deliberately continuing one focused
task:

```bash
CLAUDE_CODE_EFFORT_LEVEL=medium deepseek --continue
```

Do not use persistent continuation as the default for unrelated work. Start a
fresh session when the task, page family, audit category, or project phase
changes. Use `--no-session-persistence` for isolated tests when supported by
the installed CLI.

## Verification and accounting

The first live test must prove more than installation:

1. Use a disposable test request.
2. Ask for one harmless known response or one throwaway file operation.
3. Capture the JSON envelope when benchmarking.
4. Confirm the actual model and requested effort status.
5. Confirm file/tool access if the task requires it.
6. Check exit code and read the actual result.
7. Remove any throwaway file and confirm the working tree is clean.

Provider-reported data is authoritative. Label anything else as a CLI
estimate, and mark unavailable fields as unavailable. DeepSeek API usage does
not count as a Claude OAuth model call. Do not describe a DeepSeek estimate as
a separate Claude charge.

High or max effort may be slower and may time out. Medium is the default for
predictable completion. One active code writer per task is required. Claude
Sonnet remains the preferred worker for architecture, difficult debugging, and
final review.