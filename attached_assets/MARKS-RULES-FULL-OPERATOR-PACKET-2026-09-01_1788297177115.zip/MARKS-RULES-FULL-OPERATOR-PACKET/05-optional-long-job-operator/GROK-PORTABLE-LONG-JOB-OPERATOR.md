# Portable Grok CLI setup prompt

Paste the block below into a **different Replit chat** to reproduce this Grok setup in another project.

It covers three failure classes. Fixing only one leaves you broken in the others:

1. **Quality** — fabricated findings from broad, tool-enabled prompts.
2. **Operational** — long jobs dying from shell timeouts, process reaping, turn caps, and a wiped Grok home.
3. **Cost/quota** — OAuth quota throttling that masquerades as a hang, plus popular advice that actively breaks unattended runs.

---

## COPY FROM HERE

I want you to set up the Grok CLI in this Replit project for me. I am not very technical. I can
open the Shell tab, paste a command, and complete an OAuth login in my browser. After that, you
do everything else.

Read this entire brief before you start. It encodes failures from another project that were
expensive to diagnose. There are THREE independent failure classes. Fixing one leaves the others.

##############################################################################
# PART A — QUALITY FAILURES (fabrication)
##############################################################################

Grok is a frontier-level model, so when output degrades the cause is almost never raw capability.
The SAME model version produced:

- EXCELLENT work when given one bounded task, an explicit source of truth, a required verification
  command, and independent checking afterward.
- BADLY UNRELIABLE work when given a broad, multi-axis audit ("review SEO + accessibility + design
  + routes + claims across these directories") with full tool access to the repository.

In the failing mode it:
- cited routes and file paths from a COMPLETELY DIFFERENT project that did not exist in our repo;
- pulled a protected sibling directory into findings scoped to one app;
- invented JSON fields to satisfy a strict output schema;
- CONTRADICTED EVIDENCE PASTED INTO ITS OWN PROMPT (claimed a meta tag was missing when it was
  visible in the supplied text);
- timed out, leaving partial interleaved output that LOOKED like a finished report.

Root cause, in priority order:
1. TOOL/REPO ACCESS + A BROAD PROMPT. Free to explore, the model expands the request into a generic
   template for that task type and fills gaps with plausible invented material.
2. OVERSIZED, MULTI-AXIS SCOPE, which triggers the exploration.
3. TURN AND TIME BUDGETS. A timeout does not fail cleanly; it yields a partial answer that reads
   like a conclusion.
4. OUTPUT SCHEMA WITHOUT EVIDENCE BINDING. A schema constrains SHAPE, not TRUTH. Requiring JSON
   made fabrication look MORE authoritative.
5. CROSS-SESSION MEMORY leaking stale context from unrelated tasks.
6. MODEL VERSION — NOT A FACTOR. Tested explicitly; same failure profile across versions.

Fix: a COMMITTED WRAPPER SCRIPT that enforces the safe profile on EVERY run, so nobody has to
remember flags.

IMPLEMENTATION MODE (where Grok excels):
- One bounded phase, file, or directory per run.
- Name the exact source of truth and the single deliverable.
- Require Grok to run a verification command itself.
- Then INDEPENDENTLY check diff/typecheck/build. Never accept self-reported success — it will
  report edits it did not persist.

AUDIT/REVIEW MODE (where it failed):
- Do NOT let it crawl the repo. Extract evidence yourself; paste only that in.
- One turn, no tools, no memory, no web, no subagents.
- Every claim must cite a line from the supplied evidence.
- Your deterministic checks are the baseline. Grok is a second opinion, NEVER the source of truth.

##############################################################################
# PART B — OPERATIONAL FAILURES (long jobs) — THE COMMONLY MISSED HALF
##############################################################################

### B1. THE AGENT SHELL CANNOT HOST A LONG JOB — BUT A MANAGED WORKFLOW CAN

Two separate facts. Do not collapse them (an earlier version of this brief did, and the conclusion
was too restrictive).

FACT 1 — the agent's SHELL TOOL cannot host a long job:
- Hard 300-second (5 minute) cap per command.
- When the call ends, Replit reaps the ENTIRE PROCESS TREE. `setsid`, `nohup`, and subshell
  backgrounding were all tested and ALL WERE KILLED.

FACT 2 — a Replit MANAGED WORKFLOW survives, because it is owned by the platform supervisor rather
than by the agent's call. Measured directly: a heartbeat workflow kept the SAME PID across several
ended agent calls, parented to the supervisor, well past the 300s ceiling.

THE REAL VARIABLE IS WHO SUPERVISES THE PROCESS, NOT WHETHER IT WAS "DETACHED." Detaching from a
doomed process tree does nothing. Handing the process to a long-lived supervisor is what works.

CRITICAL DETAIL FOR ONE-SHOT BUILDS: a workflow whose command EXITS 0 is marked `finished` and is
NOT relaunched. Verified with a job that slept 20s and exited — exactly one start, no restart loop.
So a workflow is safe for a one-shot build; you will not get an infinite rebuild. (Confirm this in
your environment before trusting it — a restart-on-exit supervisor would silently rerun your build
forever.)

PREFERRED PATTERN (no human babysitting):
1. `prepare "<prompt>"` stages a job dir with the prompt and a stable session id, prints a job id.
2. The agent registers a workflow whose command is `run-job <job_id>` — a FOREGROUND runner that
   writes `output.log` and, on completion, an `exit_code` file. It must stay in the foreground: if
   it returns early, the supervisor thinks the job is done.
3. The agent polls `watch <job_id>` from its own short calls.

FALLBACK (only if managed workflows are unavailable): the human pastes the job into the Replit
Shell tab and keeps it open. Keep this path, but do not present it as the only option.

Never let the agent claim a job launched from its own shell is "detached and will survive." Mine
printed exactly that and it was false.

### B2. TURN LIMITS SILENTLY MASQUERADE AS SUCCESS

A single hard `--max-turns` is wrong. Use TWO profiles:
- AUDIT profile: low cap (e.g. 50). Bounded, one-shot.
- LONG profile: high cap (e.g. 400) for multi-page builds.

A build that dies at the turn cap stops cleanly and looks done. Detect turn exhaustion as FAILURE.

### B3. UNATTENDED APPROVAL IS MANDATORY — AND PLAN MODE IS FORBIDDEN

A long job with no TTY stalls forever at the first permission prompt. Pin `--always-approve` (or
`--permission-mode dontAsk`/`bypassPermissions`) in the resolved args and ASSERT it in the health
check. Deny-rules still protect anything that must never be touched.

COROLLARY — IGNORE THE COMMON "USE PLAN MODE" ADVICE FOR UNATTENDED RUNS. Plan mode gates file
edits on a human keypress. On a detached job nobody is watching the terminal, so it deadlocks at
the first gate and is indistinguishable from a hang. That advice assumes an interactive TUI.
Pass `--no-plan`. Same for slash commands (`/compact`, `/usage`, `/minimal`, `/session-info`) —
they exist only in the interactive UI and do nothing in headless `-p` runs.

### B4. DEFINE A COMPLETION CONTRACT

Turn exhaustion, the 300s kill, a container restart, quota throttling, and a stalled prompt all
produce the same artifact: a log that looks like a result. So "done" must mean ALL of:
  1. a done-marker file exists, AND
  2. the recorded exit code is 0, AND
  3. an independent build/typecheck/diff review passed.
Never treat stdout or a truncated log as success. Report "STOPPED — no exit code" honestly rather
than guessing.

### B5. SESSIONS vs MEMORY — KEEP ONE, DISABLE THE OTHER

Conflating these costs you the recovery path.
- `--no-memory` (cross-session memory) stays OFF — it is a contamination source.
- SESSIONS are the resume mechanism and are ESSENTIAL for long jobs.
Give every long job a stable `--session-id`. If interrupted, resume with `--resume <id>` /
`--continue` instead of starting cold over half-written files.
Useful: `grok sessions list`, `--fork-session`.

### B6. THE GROK HOME IS EPHEMERAL — VERIFIED, NOT ASSUMED

I checked: NOTHING in `~/.grok` was older than the current day, and `auth.json` had been recreated.
The original long build was two days earlier. The entire home — binary, login, and ALL session
history — had been wiped in between.

CONSEQUENCES:
- Never promise the user their login persists. Always health-check first.
- A missing binary is the usual cause of "Grok stopped working."
- Session history is NOT an archive. After any significant job run `grok export <session-id>` and
  write the transcript INTO THE REPO, or the record of the run that worked is unrecoverable.
- THE ONLY DURABLE THING IS THE WRAPPER COMMITTED IN THE REPO. Consistency must come from it
  re-applying the profile every run — never from the model remembering anything.

### B7. DISK GROWTH CAUSES CRYPTIC MID-BUILD FAILURES

`grok du` showed ~193 MB (158 MB of it a downloads cache). A full disk surfaces as confusing write
errors deep in a build that read like model failure. Have the health check report `~/.grok` size and
free space and fail loudly under a threshold. Safe to clear: the downloads cache. NEVER delete
`auth.json` or an in-flight session.

### B8. TRANSIENT PROBE FAILURES CAUSE NEEDLESS REINSTALLS

A live one-turn probe failed twice, then succeeded with IDENTICAL arguments. If a health check
reports a bare "probe failed", a non-technical owner will start reinstalling for no reason.
Retry a few times, and ALWAYS print the real error and exit code. On OAuth logins the most likely
cause is QUOTA THROTTLING (see Part C), not a broken install.

### B9. OTHER DIAGNOSTICS TO WIRE IN, NOT IGNORE

- `grok doctor` — run BEFORE concluding "reinstall" or "log in again".
- `grok leader list` — orphaned leader processes from a killed long job.
- `--debug-file <path>` — for diagnosing a long job that failed opaquely.

##############################################################################
# PART C — COST AND QUOTA (OAuth vs API key)
##############################################################################

There is a widely-circulated analysis claiming Grok "doubles in price above 200K tokens" and is
therefore a bad value for long-context work. Understand exactly when it applies:

- TRUE for API-key usage (`XAI_API_KEY`): once a single request crosses ~200K prompt tokens, the
  ENTIRE request bills at the higher rate. Not a ramp — the whole turn flips.
- NOT APPLICABLE on OAuth/subscription login: there is no per-token bill. You draw from a
  subscription quota pool.

So on OAuth there is no surprise charge and no reason to switch models or start a fresh chat "for
pricing reasons." What long sessions DO consume is quota.

HONESTY FLAG — THIS PART IS A HYPOTHESIS, NOT A VERIFIED FINDING. An earlier version of this brief
told you to "check quota before reinstalling." That advice was not actionable and is retracted as
stated. What is actually established:

- VERIFIED: a one-turn probe failed twice, then succeeded with IDENTICAL arguments. The failure was
  never root-caused; no rate-limit or quota error was ever captured.
- VERIFIED: the CLI exposes NO usage/quota/limits command (checked against `--help`; `du` is disk
  usage, not quota). So there is no in-CLI way to "check quota." Any brief telling you to do so
  owes you the command, and there isn't one.
- HYPOTHESIS ONLY: throttling is a plausible explanation for identical-args flakiness on a
  subscription login. Treat it as a candidate, not a diagnosis.

WHAT TO DO INSTEAD: make the failure legible rather than guessing. Capture the exact stderr and
exit code on probe failure, retry a few times, and only escalate to reinstall/re-auth if the error
text actually indicates it. Do not reinstall on a bare "probe failed" — that was the real bug.

REDUCE CONTEXT — it serves quality AND quota at once:
- Add a `.grokignore` (and keep `.gitignore` clean) excluding `node_modules/`, `dist/`, `build/`,
  lockfiles, `*.log`, caches, and binary/media assets. A smaller context both starves the model's
  tendency to roam and invent, and burns less of the pool.
- One clear job per session. Do not let a session grow forever.

TREAT UNVERIFIED CONFIG KEYS WITH SUSPICION. Several widely-shared `~/.grok/config.toml` settings
(media-tool toggles, auto-compact thresholds, assorted env vars) did NOT exist in the installed
CLI. Confirm against `grok inspect` or the CLI's own `--help` before adding anything. Advice about
this CLI is itself frequently hallucinated — including advice that cites sources.

##############################################################################
# PART D — WHAT TO BUILD
##############################################################################

D1. INSTALL (only if the binary is missing):

    curl -fsSL https://x.ai/cli/install.sh -o /tmp/grok-install.sh
    bash /tmp/grok-install.sh
    export PATH="$HOME/.grok/bin:$PATH"

  A `.bashrc` permission warning on Replit is harmless — the binary still installs. Handle that
  case rather than treating it as failure.

D2. A WRAPPER SCRIPT that is the ONLY way Grok is ever invoked. Always passes:
    --cwd <the one directory Grok may work in>
    --model <pinned model>      (pin explicitly; never rely on the CLI default)
    --always-approve            (or an equivalent unattended permission mode)
    --no-memory --no-plan --no-subagents --disable-web-search
    --max-turns <low for audit, high for long>
    --deny rules for protected dirs, git push, git reset --hard, rm -rf

  Commands: login, status, health, bootstrap, doctor, list,
  new/continue/resume (short jobs), long (prints the Shell-tab paste command),
  jobs + watch (poll honestly), export (save transcript to repo), print-args.

D3. A HEALTH CHECK verifying: binary present; `auth.json` present with 600 perms; pinned model
  available; ALL guardrails active; unattended approval active; long-job commands exist; disk
  headroom; and optionally a live probe WITH RETRIES and a quota hint on failure.

  THREE TRAPS WE ACTUALLY PAID FOR:
  1. Do NOT verify guardrails by grepping the wrapper's source text — a commented-out or merely
     mentioned flag yields a FALSE PASS. Add a `print-args` command that echoes the RESOLVED
     argument array and assert against THAT. Prove it by deliberately removing a flag and
     confirming the check FAILS.
  2. Do NOT put an "is the CLI installed?" guard in front of the command whose job is to install it.
     We shipped exactly that: the documented recovery command exited 127 when the binary was
     missing — the precise case it existed for. Dispatch bootstrap/help BEFORE any binary check.
  3. Do NOT let the health check pass while a long job is still impossible. Guardrails green +
     20-minute job dead is the worst outcome, because it looks fine.

D4. A BOOTSTRAP SCRIPT safe to run anytime: check first, install only if missing, NEVER delete or
  reset `~/.grok` (that destroys login and sessions). Prompt for sign-in only when auth is absent.

##############################################################################
# PART E — THE FLOW I NEED PERSONALLY
##############################################################################

1. When I ask for Grok, you run the health check FIRST, automatically.
2. If anything is missing, you STOP and give me ONE command to paste in the Shell tab.
3. If sign-in is needed, I run `grok login --device-auth` in the FOREGROUND Shell tab, open the URL,
   enter the code, and wait for the signed-in confirmation. NEVER background this — Replit kills
   backgrounded login pollers and the browser confirmation ends up with nothing listening. This is
   why repeated OAuth attempts can appear to fail for no reason.
4. For a LONG job, you give me ONE paste command, I run it in the Shell tab and keep it open, and I
   report the job id back to you. You poll and verify from there.
5. Never ask me for the token, password, or contents of `~/.grok/auth.json`.

THE PAIRED RULE, STATED EXPLICITLY (we got this half-right and it still broke):
  - `grok login` = FOREGROUND Shell tab only, never backgrounded.
  - Long agent work = human-owned Shell tab + polling, NEVER a blocking agent call and NEVER a
    fake "detached" launch from the agent.

##############################################################################
# PART F — SAVE IT PERMANENTLY
##############################################################################

Write the above into `replit.md` (or this project's always-read equivalent) as a MANDATORY AGENT
RULE, plus a plain-English recovery section for me. Include: the one Shell command I paste; what
success looks like; that Grok is NEVER invoked outside the wrapper; the long-job handoff; that
plan mode must stay off; that quota is the real constraint, not a hidden bill; and that
"No sessions found" after a fresh login is normal.

Then verify end-to-end and SHOW ME THE EVIDENCE, including:
  - the negative test proving the health check can actually FAIL, and
  - the process-reaping test from B1 for THIS environment.

## COPY TO HERE

---

## Notes for this project's agent

AVA implementation:

- `artifacts/ava-redesign/scripts/grok-replit.sh` — wrapper; audit + long profiles,
  `long`/`jobs`/`watch`/`export`, `print-args`, deny rules.
- `artifacts/ava-redesign/scripts/grok-bootstrap.sh` — idempotent install/check; never resets `~/.grok`.
- `artifacts/ava-redesign/scripts/grok-health-check.sh` — asserts resolved args, long-job readiness,
  disk headroom; probe retries with real error output and a quota hint.
- `artifacts/ava-redesign/.grokignore` — context starvation for quality and quota.
- `replit.md` — mandatory agent rule and the owner's plain-English steps.

Verified in this environment: agent shell caps at 300s; `setsid`, `nohup`, and subshell
backgrounding are ALL reaped when the call ends; `~/.grok` had been wiped within two days.
