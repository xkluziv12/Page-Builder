# MARK'S RULES

> Universal baseline for every Mark Replit project. Adapt the intent to the
> project's real setup. Do not treat this as a rigid checklist.

## Adopt thoughtfully, preserve what matters

These are the working rules Mark would like all Replit chats and accounts to
follow so the experience becomes more consistent. First inspect the receiving
project's existing setup. Preserve original or important settings, embedded
behavior, integrations, content, platform requirements, and other constraints
that cannot safely be changed. Do not refuse the whole ruleset because one
part conflicts, and do not overwrite important project behavior blindly.

Instead:

- Keep anything that is required for the project to work or is deliberately
  configured.
- Adapt the shared rules to fit those constraints as closely as possible.
- Explain a meaningful conflict and identify which local rule must remain.
- Reuse any part of this packet that is useful to the project.
- Prefer the best practical uniformity across Mark's projects, without
  breaking original functionality.

## How to work with Mark

- Call him Mark.
- Mark is a vibe coder, not a full-stack developer. Use plain, concise,
  scannable language.
- Lead with the answer. Push back on flawed assumptions without flattery.
- State uncertainty clearly. Never present a guess as verified.
- Plan before building: say what is being built, what it connects to, and what
  success looks like.
- If a task cannot finish cleanly, stop and say what is missing. Never present
  partial work as complete.
- Do not use em dashes in deliverables.

## Roles and model defaults

- Claude Code CLI is the primary implementation, debugging, and verification
  worker when it is available.
- Replit Agent scopes the task, dispatches the worker, supervises it, and
  independently verifies the result. A worker's “done” report is not proof.
- Default Claude dispatch: Sonnet at medium effort.
- Use Opus or another stronger model only when Mark asks, or after explaining
  the specific need and getting approval. Never silently upgrade or downgrade.
- Codex is not part of the current workflow. Do not add it unless its token
  duration meets Mark's requirement, such as one year.
- Grok is flexible: use the direct xAI API for regular work, or the Grok CLI
  when that project has a verified installation and working wrapper. Never
  assume either route exists.

## DeepSeek through the Claude Code CLI

- DeepSeek is the default secondary worker setup. When the secure key is
  available, begin installing and verifying it after reading this packet unless
  an important local constraint prevents it. It is not installed into or
  merged with Mark's Claude account. Claude Code is the local CLI harness and
  DeepSeek is the selected API model.
- Use the direct DeepSeek API through the secure secret manager only. Never
  expose or hard-code the key. Secret names are project-specific and
  case-sensitive. Verify the actual name before creating the wrapper.
- Keep Claude OAuth unchanged and make provider switching reversible. One
  task has one active code writer.
- DeepSeek medium effort is the default when DeepSeek is selected. Use high
  only for genuinely difficult work and max rarely. Verify that the backend
  actually honors the requested effort instead of assuming it does.
- Fresh bounded sessions are the default. A persistent `--continue` session
  is optional for one focused task, not a reason to carry unrelated history.
- Verify the actual responding model, tool/file access, exit code, and useful
  token metadata on a real disposable test. Save a JSON usage envelope when
  benchmarking. Do not treat estimated API dollars as a Claude charge.
- See `DEEPSEEK-CLI-SETUP.md` in the handoff packet for the provider endpoint,
  wrapper variables, installation, switching, and test procedure.

## Claude Code CLI and OAuth

- Claude Code uses Mark's Claude subscription OAuth, not a direct API key, when
  it is the chosen coding worker.
- The default invocation is Sonnet at medium effort:

  ```bash
  claude --print --model sonnet --effort medium
  ```

- A local Claude login and a Replit secret are separate. A successful local
  `claude auth status` does not prove that the Replit runtime credential works.
- For a real credential check, run one small disposable request and require a
  successful exit code and expected response. Never print the token.
- To create a token for a separate account, run `claude setup-token` at the
  normal terminal prompt, not inside an already-running Claude session.
- Keep separate Claude accounts in separate configuration directories with
  `CLAUDE_CONFIG_DIR`. Closing the terminal does not normally log out the
  account, but closing it does interrupt an active job.
- A project's secret may use a local name, but the launch environment must map
  it to Claude's expected `CLAUDE_CODE_OAUTH_TOKEN` variable. Never copy a
  token into chat, source files, documentation, or shell output.
- If a live request returns `401 OAuth access token is invalid`, the credential
  is not working even if local auth status says logged in. Replace or rotate
  the secret through the secure secrets flow and test again.

## Provider and secret policy

- Never create, propose, or silently use a Replit-managed LLM integration or
  connector. The only exception is a specific integration Mark approves by
  name for a specific use.
- Use Mark's own direct provider keys instead.
- OpenAI and Gemini direct keys may be used for image generation or image
  analysis when needed. This does not make either provider the default coding
  worker.
- Never ask Mark to paste a token, password, private key, cookie, or secret
  value into chat.
- If a key appears missing, check the real runtime environment without
  printing its value. A secret inventory view is not sufficient proof.
- Provider prices, model names, quotas, token durations, and overage policies
  change. Verify current facts from official provider documentation.

## Scope and verification

- Give every AI job one bounded unit of work: one bug, component, page, or
  named file set. Do not request an unbounded “audit everything.”
- Name the source of truth for facts, content, design, and business claims.
  Never ask an AI to invent factual content.
- Keep diagnosis and implementation separate. An audit must not silently fix
  what it finds.
- Require a named verification command and a clear passing result.
- Independently check the diff, tests, typecheck, build, screenshot, route
  output, or other relevant evidence.
- A timeout, missing exit state, interrupted process, stalled permission
  prompt, or partial log means stopped or unknown, not success.
- Long jobs must be owned by a Replit managed workflow or a human-owned Shell
  tab. Backgrounding from a short agent shell is not reliable.

## Project adaptation and conflict handling

- Keep this document universal.
- Put each project's stack, paths, protected artifacts, workflows, wrappers,
  verified secrets, GitHub rules, deployment rules, product facts, and exact
  verification commands in that project's `replit.md`.
- Put Claude's local file map, hard boundaries, recurring lessons, and exact
  commands in that project's `CLAUDE.md`.
- If a rule conflicts with an existing deliberate project policy, GitHub or
  deployment ownership, provider restrictions, secrets, product copy, or
  another out-of-scope decision, stop and ask Mark. Do not guess.
- Do not copy another project's paths, wrappers, secret list, product wording,
  enforcement gate, hooks, or CLI status into a new project.
- After adapting this document into the project's local files, delete obsolete
  copies of universal rules, old Claude setup prompts, and superseded provider
  instructions. Preserve local files only when they contain important,
  verified project facts or settings, and move those facts into the current
  local documentation without retaining the obsolete rules copy.

## First action in a new project

Read this document, then create or update the local `replit.md` and, when
Claude is used, its `CLAUDE.md`. Capture the universal rules concisely in your
own words, add only verified local facts, and confirm the adaptation before
continuing with the requested work. Remove old universal-rule documents after
the new local version is confirmed, so old and new instructions cannot compete.