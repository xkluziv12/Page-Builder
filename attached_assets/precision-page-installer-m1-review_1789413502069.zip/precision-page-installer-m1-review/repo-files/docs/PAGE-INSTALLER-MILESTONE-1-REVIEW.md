# Page installer milestone 1 review

## Scope

This change proves and repairs the deterministic finishing path for `CityServiceData` records. It makes no model calls, publishes nothing, and does not change `ratified-markets.ts`.

The working copy was assembled from `claude/content-blocks` at `85a911560` because the eleven-commit local merge described in the review messages was not available through GitHub. The original St. Louis writer at `83c37f9` was used as a reference. Apply or review this change against the merged branch before accepting it.

## What changed

- Added a service-spoke installer that validates nested record and `ContentBlock` shapes.
- Added it as `write-city-service-page.ts` so it does not overwrite or regress the existing hub writer on the pending merged branch.
- Removed the old short-string blind spot from credential scanning.
- Made inserts marker-owned, anchor-checked, idempotent, and collision-refusing.
- Staged every output before changing the site.
- Added rollback for a failure during the multi-file commit.
- Required a ratified market and ratified service before production installation.
- Derived `availabilityConfirmationRequired` from the ratified market status in code.
- Added the missing `service-spoke` branches to schema derivation and the review overlay.
- Made `CityServicePage` use project-review calls to action when availability requires confirmation.
- Added metadata fields to factory-built `CityServiceData` records while preserving legacy records.

## Verified here

```text
pnpm --filter @workspace/scripts run write-city-page-test
5 tests passed

pnpm --filter @workspace/precision-ecycle run typecheck
passed
```

The tests cover invalid nested FAQ data, a short false R2 claim, dry run, idempotent replacement, injected failure rollback, unratified-market refusal, and all four required service-spoke schema nodes.

## Runtime limitation in this copy

The production Vite build reached 1,392 transformed modules and then stopped because `attached_assets/brand/precision-ecycle-logo.png` is absent. The factory source says this file is supplied by the Replit workspace and is not tracked in GitHub. Do not replace it with a fake test asset. Run the rendered-route proof in the real Replit copy where the logo exists.

## Required Replit acceptance proof

Use the merged branch in an isolated Git worktree. Run the five installer tests and the site typecheck first. Then install a synthetic record with a unique route and sentinel through the test-only installer option, build the real site, and assert that the prerendered HTML for that exact route contains the sentinel H1. Run the route-scoped SEO and schema gates and restore or discard the worktree.

The production CLI intentionally has no flag that bypasses market or service ratification. The test-only bypass works only for a city slug beginning with `test-` and is available only through the programmatic test interface.

## Current business blocker

No core service is currently listed in `approvedMethods` for the ratified market records in this source revision. Therefore the production installer correctly refuses every new service-spoke record until the operator ratifies the city and service combination. This is a policy decision, not an engineering failure, and the installer must not weaken it.

## Next milestone after acceptance

Connect one saved research and generation output to this installer. Use one provider and one page type. Preserve bounded repair, transcripts, costs, prompt versions, and stage checkpoints. Do not extract a universal package until that complete Precision run passes.
