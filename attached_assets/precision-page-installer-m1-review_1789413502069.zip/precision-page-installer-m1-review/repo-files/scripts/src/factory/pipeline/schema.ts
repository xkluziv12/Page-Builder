import {
  buildSchemaGraph,
  makeBreadcrumbs,
  makeFAQPage,
  makeHowTo,
  makeLocationBusiness,
  makeService,
} from "../../../../artifacts/precision-ecycle/src/lib/schemas";
import type { PecRunContext } from "./types";

function asString(value: unknown, field: string): string {
  if (typeof value !== "string" || !value.trim()) throw new Error(`Schema cannot derive: "${field}" is missing.`);
  return value.trim();
}

function faqPairs(value: unknown): { question: string; answer: string }[] {
  if (!Array.isArray(value)) throw new Error('Schema cannot derive: "faqs" is not an array.');
  return value.map((faq, index) => {
    if (!faq || typeof faq !== "object") throw new Error(`Schema cannot derive: faqs[${index}] is invalid.`);
    const item = faq as Record<string, unknown>;
    return { question: asString(item.question, `faqs[${index}].question`), answer: asString(item.answer, `faqs[${index}].answer`) };
  });
}

function schemaTypes(graph: Record<string, unknown>): string[] {
  const nodes = Array.isArray(graph["@graph"]) ? graph["@graph"] : [];
  return nodes.flatMap((node) => {
    if (!node || typeof node !== "object") return [];
    const type = (node as Record<string, unknown>)["@type"];
    return typeof type === "string" ? [type] : Array.isArray(type) ? type.filter((item): item is string => typeof item === "string") : [];
  });
}

export function deriveSchemaGraph(
  ctx: PecRunContext,
  record: Record<string, unknown>,
  route: string,
): Record<string, unknown> {
  const breadcrumbs = [
    { name: "Home", url: "/" },
    { name: "Locations", url: "/locations" },
    { name: `${ctx.city}, ${ctx.state}`, url: `/locations/${ctx.slug}` },
  ];
  const nodes: Record<string, unknown>[] = [makeFAQPage(faqPairs(record.faqs))];

  if (ctx.recipe.id === "city-hub") {
    if (ctx.marketRecord.status === "active" && ctx.marketRecord.localBusinessEligible) {
      nodes.push(
        makeLocationBusiness({
          city: ctx.city,
          state: ctx.state,
          slug: ctx.slug,
          telephone: asString(record.phone, "phone"),
          hasDropoff: ctx.marketRecord.dropoffConfirmed,
        }),
      );
    }
  } else if (ctx.recipe.id === "method-spoke" || ctx.recipe.id === "service-spoke") {
    const serviceSlug = asString(record.serviceSlug, "serviceSlug");
    breadcrumbs.push({ name: ctx.subject?.label ?? serviceSlug, url: route });
    nodes.push(
      makeService(
        asString(record.serviceName, "serviceName"),
        asString(record.serviceSchemaDescription, "serviceSchemaDescription"),
        route,
        serviceSlug,
      ),
    );
    const howTo = record.howTo;
    const process = record.process;
    if (!howTo || typeof howTo !== "object" || !Array.isArray(process)) {
      throw new Error(`Schema cannot derive: ${ctx.recipe.id} requires howTo and process.`);
    }
    const howToRecord = howTo as Record<string, unknown>;
    nodes.push(
      makeHowTo(
        asString(howToRecord.name, "howTo.name"),
        asString(howToRecord.description, "howTo.description"),
        process.map((step, index) => {
          if (!step || typeof step !== "object") throw new Error(`Schema cannot derive: process[${index}] is invalid.`);
          const item = step as Record<string, unknown>;
          return { name: asString(item.title, `process[${index}].title`), text: asString(item.desc, `process[${index}].desc`) };
        }),
      ),
    );
  } else {
    throw new Error(`Schema cannot derive for unknown recipe "${ctx.recipe.id}".`);
  }

  nodes.unshift(makeBreadcrumbs(breadcrumbs));
  return buildSchemaGraph(nodes, { url: `https://precisionecycle.com${route}`, name: asString(record.seoTitle ?? record.heroH1, "page title") });
}

export function schemaContractFailures(
  ctx: PecRunContext,
  graph: Record<string, unknown>,
): string[] {
  const types = new Set(schemaTypes(graph));
  const expected = new Set(ctx.recipe.requiredSchemaNodes);
  if (ctx.recipe.id === "city-hub" && !(ctx.marketRecord.status === "active" && ctx.marketRecord.localBusinessEligible)) {
    expected.delete("LocalBusiness");
  }
  const failures = [...expected].filter((type) => !types.has(type)).map((type) => `missing required schema node ${type}`);
  if (ctx.marketRecord.status !== "active" && types.has("LocalBusiness")) {
    failures.push("planning or retired market emitted a LocalBusiness node");
  }
  if (!Array.isArray(graph["@graph"])) failures.push("schema graph is not connected @graph output");
  return failures;
}
