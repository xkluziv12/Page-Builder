import { closeSync, openSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { REPO_ROOT } from "../gate-runner";

const OVERLAY_PATH = resolve(
  REPO_ROOT,
  "artifacts/precision-ecycle/src/pages/_factoryReviewOverlay.ts",
);
const LOCK_PATH = `${OVERLAY_PATH}.lock`;

function overlaySource(input: {
  recipeId: string;
  slug: string;
  method?: string | null;
  record: Record<string, unknown>;
  marketStatus?: string;
  localBusinessEligible?: boolean;
}): string {
  // The rendered LocationPage deliberately decides LocalBusiness output from
  // this field. Generated content cannot override the ratified market posture.
  const record = JSON.stringify(
    {
      ...input.record,
      availabilityConfirmationRequired: input.marketStatus !== "active",
    },
    null,
    2,
  );
  if (input.recipeId === "city-hub") {
    return `import type { CityData } from "./_cityData";\nimport type { CityServiceData } from "./_cityServiceData";\n\n/** Temporary local review data. The unified factory restores this file after gates. */\nexport const factoryReviewCityData: Record<string, CityData> = {\n  ${JSON.stringify(input.slug)}: ${record} as CityData,\n};\nexport const factoryReviewCityServiceData: Record<string, CityServiceData> = {};\n`;
  }
  if ((input.recipeId === "method-spoke" || input.recipeId === "service-spoke") && input.method) {
    return `import type { CityData } from "./_cityData";\nimport type { CityServiceData } from "./_cityServiceData";\n\n/** Temporary local review data. The unified factory restores this file after gates. */\nexport const factoryReviewCityData: Record<string, CityData> = {};\nexport const factoryReviewCityServiceData: Record<string, CityServiceData> = {\n  ${JSON.stringify(`${input.slug}/${input.method}`)}: ${record} as CityServiceData,\n};\n`;
  }
  throw new Error(`Cannot stage review overlay for recipe "${input.recipeId}".`);
}

function atomicWrite(path: string, content: string): void {
  const temporary = `${path}.${process.pid}.${Date.now()}.tmp`;
  try {
    writeFileSync(temporary, content, "utf8");
    renameSync(temporary, path);
  } finally {
    try {
      unlinkSync(temporary);
    } catch {
      // The rename consumes the temporary file. A failed write is handled by
      // the caller, and cleanup must never mask that original error.
    }
  }
}

function acquireOverlayLock(): void {
  let fd: number;
  try {
    fd = openSync(LOCK_PATH, "wx");
  } catch (error) {
    throw new Error(
      `Factory review overlay is already active (${LOCK_PATH}). Refusing concurrent staging; wait for the current run or restore the reviewed baseline.`,
      { cause: error },
    );
  }
  try {
    writeFileSync(fd, `${JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString() })}\n`, "utf8");
  } finally {
    closeSync(fd);
  }
}

/**
 * Render one generated record locally for gate execution, then restore the
 * exact baseline even when a gate fails. This is a review-only staging seam:
 * it does not commit, publish, or leave generated page data wired in source.
 */
export async function withReviewOverlay<T>(
  input: {
    recipeId: string;
    slug: string;
    method?: string | null;
    record: Record<string, unknown>;
    marketStatus?: string;
    localBusinessEligible?: boolean;
  },
  run: () => Promise<T>,
): Promise<T> {
  acquireOverlayLock();
  const baseline = readFileSync(OVERLAY_PATH, "utf8");
  let restored = false;
  const restore = () => {
    if (restored) return;
    restored = true;
    try {
      atomicWrite(OVERLAY_PATH, baseline);
    } finally {
      try {
        unlinkSync(LOCK_PATH);
      } catch {
        // The lock may already be gone after a failed initial write.
      }
    }
  };
  const restoreOnSignal = (signal: NodeJS.Signals) => {
    restore();
    process.exit(signal === "SIGINT" ? 130 : 143);
  };
  const onSigint = () => restoreOnSignal("SIGINT");
  const onSigterm = () => restoreOnSignal("SIGTERM");
  process.once("SIGINT", onSigint);
  process.once("SIGTERM", onSigterm);
  try {
    atomicWrite(OVERLAY_PATH, overlaySource(input));
    return await run();
  } finally {
    process.removeListener("SIGINT", onSigint);
    process.removeListener("SIGTERM", onSigterm);
    restore();
  }
}
