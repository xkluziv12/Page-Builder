import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { installCityServiceRecord } from "./page-installer/city-service";

const args = process.argv.slice(2);
const file = args.find((arg) => !arg.startsWith("--"));
if (!file) {
  console.error("Usage: write-city-service-page <record.json> [--dry-run]");
  process.exit(2);
}

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const record = JSON.parse(readFileSync(resolve(file), "utf8")) as unknown;
const dryRun = args.includes("--dry-run");
const edits = installCityServiceRecord(record, repoRoot, { dryRun });

console.log(`${dryRun ? "Validated" : "Installed"} CityServiceData record.`);
for (const edit of edits) console.log(`  ${edit.path}`);
