import {
  existsSync,
  readFileSync,
  renameSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { resolve } from "node:path";
import { RATIFIED_MARKETS } from "../factory/pipeline/ratified-markets";

export interface InstallOptions {
  dryRun?: boolean;
  failAfterWrites?: number;
  testOnlyAllowUnratifiedFixture?: boolean;
}

export interface InstallEdit {
  path: string;
  before: string;
  after: string;
}

export interface CityServiceInstallRecord extends Record<string, unknown> {
  city: string;
  state: string;
  citySlug: string;
  serviceSlug: string;
  seoTitle: string;
  seoDescription: string;
  heroBadge: string;
  heroH1: string;
  heroSubheadline: string;
  heroImage: string;
  introHeading: string;
  introP1: string;
  introP2: string;
  includes: string[];
  processHeading: string;
  process: Array<{ step: string; title: string; desc: string }>;
  benefitsHeading: string;
  benefits: Array<{ title: string; desc: string }>;
  faqHeading: string;
  faqs: Array<{ question: string; answer: string }>;
  relatedServices: Array<{ label: string; href: string }>;
  serviceName: string;
  serviceSchemaDescription: string;
  howTo: { name: string; description: string };
  expandedSections: Array<Record<string, unknown>>;
  availabilityConfirmationRequired: boolean;
}

const REQUIRED_STRINGS = [
  "city",
  "state",
  "citySlug",
  "serviceSlug",
  "seoTitle",
  "seoDescription",
  "heroBadge",
  "heroH1",
  "heroSubheadline",
  "heroImage",
  "introHeading",
  "introP1",
  "introP2",
  "processHeading",
  "benefitsHeading",
  "faqHeading",
  "serviceName",
  "serviceSchemaDescription",
] as const;

const COUNTS: Record<string, number> = {
  includes: 6,
  process: 4,
  benefits: 3,
  faqs: 5,
  relatedServices: 6,
  expandedSections: 3,
};

const FORBIDDEN = [
  { pattern: /[–—]/u, reason: "contains an em or en dash" },
  { pattern: /\b(?:we are|we're|our)\s+R2[- ]certified/i, reason: "claims Precision holds R2" },
  { pattern: /\bNIST(?:[- ]SP)?[- ]?800-88\s+certified/i, reason: "claims NIST certification" },
  { pattern: /\bHIPAA[- ](?:certified|compliant)\b/i, reason: "claims HIPAA certification or compliance" },
  { pattern: /\b(?:NAID(?:\s+AAA)?|e-?Stewards?|SERI|RIOS)\b/i, reason: "claims an unheld credential" },
];

function stringField(value: unknown, path: string, errors: string[]): value is string {
  if (typeof value !== "string" || !value.trim()) {
    errors.push(`${path} must be a non-empty string`);
    return false;
  }
  return true;
}

function objectArray(
  value: unknown,
  path: string,
  keys: readonly string[],
  errors: string[],
): void {
  if (!Array.isArray(value)) return;
  value.forEach((item, index) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      errors.push(`${path}[${index}] must be an object`);
      return;
    }
    for (const key of keys) stringField((item as Record<string, unknown>)[key], `${path}[${index}].${key}`, errors);
  });
}

function validateBlocks(section: Record<string, unknown>, path: string, errors: string[]): void {
  stringField(section.heading, `${path}.heading`, errors);
  const blocks = section.blocks;
  const paragraphs = section.paragraphs;
  if (!Array.isArray(blocks) && !Array.isArray(paragraphs)) {
    errors.push(`${path} must contain blocks or legacy paragraphs`);
    return;
  }
  if (Array.isArray(paragraphs)) {
    paragraphs.forEach((value, index) => stringField(value, `${path}.paragraphs[${index}]`, errors));
  }
  if (!Array.isArray(blocks)) return;
  blocks.forEach((value, index) => {
    const blockPath = `${path}.blocks[${index}]`;
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      errors.push(`${blockPath} must be an object`);
      return;
    }
    const block = value as Record<string, unknown>;
    if (!stringField(block.type, `${blockPath}.type`, errors)) return;
    if (["paragraph", "subheading", "takeaway"].includes(block.type)) {
      stringField(block.text, `${blockPath}.text`, errors);
    } else if (block.type === "callout") {
      stringField(block.label, `${blockPath}.label`, errors);
      stringField(block.text, `${blockPath}.text`, errors);
    } else if (block.type === "link") {
      stringField(block.label, `${blockPath}.label`, errors);
      if (stringField(block.href, `${blockPath}.href`, errors) && !block.href.startsWith("/")) {
        errors.push(`${blockPath}.href must be an internal route`);
      }
    } else if (block.type === "bullets" || block.type === "checklist") {
      if (!Array.isArray(block.items) || block.items.length < 3) {
        errors.push(`${blockPath}.items must contain at least three strings`);
      } else {
        block.items.forEach((item, itemIndex) => stringField(item, `${blockPath}.items[${itemIndex}]`, errors));
      }
    } else if (block.type === "comparison") {
      if (!Array.isArray(block.rows) || block.rows.length < 2) {
        errors.push(`${blockPath}.rows must contain at least two comparison rows`);
      } else {
        objectArray(block.rows, `${blockPath}.rows`, ["left", "right"], errors);
      }
    } else {
      errors.push(`${blockPath}.type is not a supported ContentBlock type`);
    }
  });
}

function displayStrings(value: unknown, path = ""): Array<{ path: string; text: string }> {
  if (typeof value === "string") return [{ path, text: value }];
  if (Array.isArray(value)) return value.flatMap((item, index) => displayStrings(item, `${path}[${index}]`));
  if (!value || typeof value !== "object") return [];
  return Object.entries(value).flatMap(([key, item]) => {
    if (["citySlug", "serviceSlug", "heroImage", "href", "step"].includes(key)) return [];
    return displayStrings(item, path ? `${path}.${key}` : key);
  });
}

export function validateCityServiceRecord(value: unknown): string[] {
  const errors: string[] = [];
  if (!value || typeof value !== "object" || Array.isArray(value)) return ["record must be an object"];
  const record = value as Record<string, unknown>;

  for (const field of REQUIRED_STRINGS) stringField(record[field], field, errors);
  for (const field of ["citySlug", "serviceSlug"] as const) {
    if (typeof record[field] === "string" && !/^[a-z0-9-]+$/.test(record[field])) {
      errors.push(`${field} must be lowercase kebab-case`);
    }
  }
  for (const [field, count] of Object.entries(COUNTS)) {
    const array = record[field];
    if (!Array.isArray(array)) errors.push(`${field} must be an array of exactly ${count}`);
    else if (array.length !== count) errors.push(`${field} must contain exactly ${count} items, found ${array.length}`);
  }

  if (Array.isArray(record.includes)) {
    record.includes.forEach((item, index) => stringField(item, `includes[${index}]`, errors));
  }
  objectArray(record.process, "process", ["step", "title", "desc"], errors);
  objectArray(record.benefits, "benefits", ["title", "desc"], errors);
  objectArray(record.faqs, "faqs", ["question", "answer"], errors);
  objectArray(record.relatedServices, "relatedServices", ["label", "href"], errors);
  if (Array.isArray(record.relatedServices)) {
    record.relatedServices.forEach((item, index) => {
      const href = (item as Record<string, unknown>)?.href;
      if (typeof href === "string" && !href.startsWith("/")) errors.push(`relatedServices[${index}].href must be an internal route`);
    });
  }
  if (!record.howTo || typeof record.howTo !== "object" || Array.isArray(record.howTo)) {
    errors.push("howTo must be an object");
  } else {
    stringField((record.howTo as Record<string, unknown>).name, "howTo.name", errors);
    stringField((record.howTo as Record<string, unknown>).description, "howTo.description", errors);
  }
  if (Array.isArray(record.expandedSections)) {
    record.expandedSections.forEach((section, index) => {
      if (!section || typeof section !== "object" || Array.isArray(section)) errors.push(`expandedSections[${index}] must be an object`);
      else validateBlocks(section as Record<string, unknown>, `expandedSections[${index}]`, errors);
    });
  }

  const titleLength = typeof record.seoTitle === "string" ? record.seoTitle.length : 0;
  if (titleLength > 70) errors.push(`seoTitle is ${titleLength} characters, maximum is 70`);
  const descriptionLength = typeof record.seoDescription === "string" ? record.seoDescription.length : 0;
  if (descriptionLength < 140 || descriptionLength > 160) {
    errors.push(`seoDescription is ${descriptionLength} characters, required range is 140 to 160`);
  }
  for (const { path, text } of displayStrings(record)) {
    for (const rule of FORBIDDEN) if (rule.pattern.test(text)) errors.push(`${path}: ${rule.reason}`);
  }
  return [...new Set(errors)];
}

function replaceMarkedBlock(source: string, id: string, block: string, anchor: string): string {
  const begin = `  // page-installer:begin ${id}`;
  const end = `  // page-installer:end ${id}`;
  const marked = `${begin}\n${block}\n${end}\n`;
  const start = source.indexOf(begin);
  if (start >= 0) {
    const finish = source.indexOf(end, start);
    if (finish < 0) throw new Error(`Installer marker ${id} has no closing marker`);
    return source.slice(0, start) + marked + source.slice(finish + end.length + (source[finish + end.length] === "\n" ? 1 : 0));
  }
  const anchorIndex = source.indexOf(anchor);
  if (anchorIndex < 0 || source.indexOf(anchor, anchorIndex + anchor.length) >= 0) {
    throw new Error(`Expected exactly one insertion anchor for ${id}`);
  }
  return source.slice(0, anchorIndex + anchor.length) + marked + source.slice(anchorIndex + anchor.length);
}

function tsObject(value: unknown): string {
  return JSON.stringify(value, null, 2)
    .split("\n")
    .map((line, index) => (index === 0 ? line : `  ${line}`))
    .join("\n");
}

function prepareEdits(record: CityServiceInstallRecord, repoRoot: string): InstallEdit[] {
  const route = `/locations/${record.citySlug}/${record.serviceSlug}`;
  const key = `${record.citySlug}/${record.serviceSlug}`;
  const app = resolve(repoRoot, "artifacts/precision-ecycle/src");
  const dataPath = resolve(app, "pages/_cityServiceData.ts");
  const metaPath = resolve(app, "lib/pageMeta.ts");
  const dataBefore = readFileSync(dataPath, "utf8");
  const metaBefore = readFileSync(metaPath, "utf8");
  const dataCollision = `${JSON.stringify(key)}:`;
  if (dataBefore.includes(dataCollision) && !dataBefore.includes(`page-installer:begin data:${key}`)) {
    throw new Error(`Record ${key} already exists without installer ownership; refusing to overwrite it`);
  }
  const dataBlock = `  ${JSON.stringify(key)}: ${tsObject(record)} as CityServiceData,`;
  const dataAfter = replaceMarkedBlock(
    dataBefore,
    `data:${key}`,
    dataBlock,
    "export const cityServiceData: Record<string, CityServiceData> = {\n",
  );

  const routeCollision = `  | ${JSON.stringify(route)}`;
  if (metaBefore.includes(routeCollision) && !metaBefore.includes(`page-installer:begin route:${route}`)) {
    throw new Error(`Route ${route} already exists without installer ownership; refusing to duplicate it`);
  }
  let metaAfter = replaceMarkedBlock(
    metaBefore,
    `route:${route}`,
    `${routeCollision}`,
    "export type PageMetaRoute =\n",
  );
  const metaEntry = `  ${JSON.stringify(route)}: {\n` +
    `    title: ${JSON.stringify(record.seoTitle)},\n` +
    `    description: ${JSON.stringify(record.seoDescription)},\n` +
    `    image: ${JSON.stringify(record.heroImage)},\n` +
    "    hasFAQSchema: true,\n" +
    "  },";
  metaAfter = replaceMarkedBlock(metaAfter, `meta:${route}`, metaEntry, "const pageMeta: Record<PageMetaRoute, PageMetaEntry> = {\n");
  return [
    { path: dataPath, before: dataBefore, after: dataAfter },
    { path: metaPath, before: metaBefore, after: metaAfter },
  ];
}

function commitEdits(edits: InstallEdit[], failAfterWrites?: number): void {
  const nonce = `${process.pid}.${Date.now()}`;
  const staged = edits.map((edit) => ({ ...edit, temp: `${edit.path}.${nonce}.tmp`, backup: `${edit.path}.${nonce}.bak` }));
  let committed = false;
  try {
    for (const edit of staged) writeFileSync(edit.temp, edit.after, "utf8");
    let writes = 0;
    for (const edit of staged) {
      renameSync(edit.path, edit.backup);
      renameSync(edit.temp, edit.path);
      writes++;
      if (failAfterWrites !== undefined && writes >= failAfterWrites) throw new Error("Injected installer transaction failure");
    }
    committed = true;
  } catch (error) {
    for (const edit of [...staged].reverse()) {
      if (existsSync(edit.backup)) {
        if (existsSync(edit.path)) unlinkSync(edit.path);
        renameSync(edit.backup, edit.path);
      }
      if (existsSync(edit.temp)) unlinkSync(edit.temp);
    }
    throw error;
  } finally {
    if (committed) {
      for (const edit of staged) {
        if (existsSync(edit.backup)) {
          try {
            unlinkSync(edit.backup);
          } catch {
            // A leftover backup is recoverable and must not turn a completed transaction into a false failure.
          }
        }
      }
    }
  }
}

export function installCityServiceRecord(
  value: unknown,
  repoRoot: string,
  options: InstallOptions = {},
): InstallEdit[] {
  const errors = validateCityServiceRecord(value);
  if (errors.length > 0) throw new Error(`CityServiceData validation failed:\n- ${errors.join("\n- ")}`);
  const input = value as CityServiceInstallRecord;
  const market = RATIFIED_MARKETS[input.citySlug];
  const testFixtureAllowed = options.testOnlyAllowUnratifiedFixture === true && input.citySlug.startsWith("test-");
  if (!market && !testFixtureAllowed) {
    throw new Error(`Market ${input.citySlug} has no ratified record; installation refused`);
  }
  if (market) {
    const approved = market.record.approvedMethods ?? [];
    const prohibited = market.record.prohibitedMethods ?? [];
    if (!approved.includes(input.serviceSlug) || prohibited.includes(input.serviceSlug)) {
      throw new Error(`Service ${input.serviceSlug} is not ratified for market ${input.citySlug}; installation refused`);
    }
  }
  const record: CityServiceInstallRecord = {
    ...input,
    availabilityConfirmationRequired: market ? market.record.status !== "active" : true,
  };
  const edits = prepareEdits(record, repoRoot);
  if (!options.dryRun) commitEdits(edits, options.failAfterWrites);
  return edits;
}
