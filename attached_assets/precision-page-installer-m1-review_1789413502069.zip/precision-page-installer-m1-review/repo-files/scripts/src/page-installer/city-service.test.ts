import assert from "node:assert/strict";
import { copyFileSync, mkdtempSync, mkdirSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { installCityServiceRecord, validateCityServiceRecord } from "./city-service";
import { deriveSchemaGraph, schemaContractFailures } from "../factory/pipeline/schema";
import { RATIFIED_MARKETS } from "../factory/pipeline/ratified-markets";
import { serviceSpokeRecipe } from "../../../factory/auto-builder/registry/recipes/service-spoke";
import type { PecRunContext } from "../factory/pipeline/types";

const sourceRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../../..");

function record() {
  const paragraph =
    "INSTALL-SENTINEL-7f3a This fixture proves that a new structured record reaches the shared production template. It contains no business availability claim and exists only inside an isolated test checkout.";
  return {
    city: "Test City",
    state: "ZZ",
    citySlug: "test-city-zz",
    serviceSlug: "test-service-zz",
    seoTitle: "Test City Structured Page Installation Proof | Precision E-Cycle",
    seoDescription:
      "Verify that one structured service record installs into the shared site template, renders at a new route, and retains deterministic metadata and schema output.",
    heroBadge: "Installation Test",
    heroH1: "INSTALL-SENTINEL-7f3a Structured Installation Proof",
    heroSubheadline: paragraph,
    heroImage: "/images/computer-recycling-hero.png",
    introHeading: "A Fixture That Cannot Match an Existing Page",
    introP1: paragraph,
    introP2: paragraph,
    includes: Array.from({ length: 6 }, (_, index) => `Fixture requirement ${index + 1} remains deterministic and reviewable.`),
    processHeading: "How the Installation Proof Works",
    process: Array.from({ length: 4 }, (_, index) => ({
      step: `0${index + 1}`,
      title: `Deterministic step ${index + 1}`,
      desc: paragraph,
    })),
    benefitsHeading: "What This Test Establishes",
    benefits: Array.from({ length: 3 }, (_, index) => ({ title: `Evidence ${index + 1}`, desc: paragraph })),
    faqHeading: "Installation Proof Questions",
    faqs: Array.from({ length: 5 }, (_, index) => ({
      question: `What does fixture question ${index + 1} prove?`,
      answer: paragraph,
    })),
    relatedServices: Array.from({ length: 6 }, (_, index) => ({
      label: `Internal test link ${index + 1}`,
      href: `/test-link-${index + 1}`,
    })),
    serviceName: "Structured Installation Proof",
    serviceSchemaDescription: paragraph,
    howTo: { name: "Install a Structured Page Fixture", description: paragraph },
    expandedSections: Array.from({ length: 3 }, (_, index) => ({
      heading: `Fixture section ${index + 1}`,
      blocks: [
        { type: "paragraph", text: paragraph },
        { type: "checklist", items: ["Validate the record", "Stage every edit", "Render the new route"] },
      ],
    })),
  };
}

function isolatedRepo(): string {
  const root = mkdtempSync(resolve(tmpdir(), "pec-installer-"));
  const files = [
    "artifacts/precision-ecycle/src/pages/_cityServiceData.ts",
    "artifacts/precision-ecycle/src/lib/pageMeta.ts",
  ];
  for (const relative of files) {
    const target = resolve(root, relative);
    mkdirSync(dirname(target), { recursive: true });
    copyFileSync(resolve(sourceRoot, relative), target);
  }
  return root;
}

test("validates nested shapes and short prohibited claims", () => {
  const broken = record();
  delete (broken.faqs[2] as Partial<(typeof broken.faqs)[number]>).answer;
  broken.includes[0] = "Our R2-certified team";
  const errors = validateCityServiceRecord(broken);
  assert(errors.some((error) => error.includes("faqs[2].answer")));
  assert(errors.some((error) => error.includes("claims Precision holds R2")));
});

test("dry run changes nothing and install is idempotent", () => {
  const root = isolatedRepo();
  const dataPath = resolve(root, "artifacts/precision-ecycle/src/pages/_cityServiceData.ts");
  const baseline = readFileSync(dataPath, "utf8");
  const dryRun = installCityServiceRecord(record(), root, { dryRun: true, testOnlyAllowUnratifiedFixture: true });
  assert.equal(dryRun.length, 2);
  assert.equal(readFileSync(dataPath, "utf8"), baseline);

  installCityServiceRecord(record(), root, { testOnlyAllowUnratifiedFixture: true });
  const first = readFileSync(dataPath, "utf8");
  assert.match(first, /INSTALL-SENTINEL-7f3a/);
  installCityServiceRecord(
    { ...record(), heroH1: "INSTALL-SENTINEL-7f3a Updated Proof" },
    root,
    { testOnlyAllowUnratifiedFixture: true },
  );
  const second = readFileSync(dataPath, "utf8");
  assert.match(second, /Updated Proof/);
  assert.equal((second.match(/page-installer:begin data:test-city-zz\/test-service-zz/g) ?? []).length, 1);
});

test("a failed multi-file commit rolls every file back", () => {
  const root = isolatedRepo();
  const paths = [
    resolve(root, "artifacts/precision-ecycle/src/pages/_cityServiceData.ts"),
    resolve(root, "artifacts/precision-ecycle/src/lib/pageMeta.ts"),
  ];
  const baseline = paths.map((path) => readFileSync(path, "utf8"));
  assert.throws(
    () => installCityServiceRecord(record(), root, { failAfterWrites: 1, testOnlyAllowUnratifiedFixture: true }),
    /Injected installer transaction failure/,
  );
  paths.forEach((path, index) => assert.equal(readFileSync(path, "utf8"), baseline[index]));
});

test("production installation refuses an unratified market", () => {
  const root = isolatedRepo();
  assert.throws(() => installCityServiceRecord(record(), root), /has no ratified record/);
});

test("service-spoke schema reaches Service, FAQPage, HowTo, and BreadcrumbList", () => {
  const fixture = record();
  const ctx = {
    city: fixture.city,
    state: fixture.state,
    slug: fixture.citySlug,
    recipe: serviceSpokeRecipe,
    marketRecord: RATIFIED_MARKETS["st-louis"].record,
    subject: { slug: fixture.serviceSlug, label: "Installation Proof" },
  } as unknown as PecRunContext;
  const route = `/locations/${fixture.citySlug}/${fixture.serviceSlug}`;
  const graph = deriveSchemaGraph(ctx, fixture, route);
  assert.deepEqual(schemaContractFailures(ctx, graph), []);
  const nodes = graph["@graph"] as Array<Record<string, unknown>>;
  const types = new Set(nodes.flatMap((node) => Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]]));
  for (const expected of ["Service", "FAQPage", "HowTo", "BreadcrumbList"]) assert(types.has(expected));
});
