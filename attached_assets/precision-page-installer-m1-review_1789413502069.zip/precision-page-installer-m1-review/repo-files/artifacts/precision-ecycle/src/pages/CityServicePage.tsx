import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight, Phone, Award, Truck, Shield, FileText, HeartPulse, Banknote, Landmark, GraduationCap, Server, HardDrive, Scissors, Zap, Laptop } from "lucide-react";
import SchemaScript from "@/components/SchemaScript";
import { makeBreadcrumbs, makeService, makeFAQPage, makeHowTo } from "@/lib/schemas";
import PageMeta from "@/components/PageMeta";
import { cityServiceData } from "./_cityServiceData";
import { nicheSpokeData } from "./_nicheSpokeData";
import { methodSpokeData } from "./_methodSpokeData";
import { factoryReviewCityServiceData } from "./_factoryReviewOverlay";
import pageMeta, { type PageMetaRoute } from "@/lib/pageMeta";
import { siteConfig } from "@/lib/siteConfig";
import { buildCityLeadAnswer } from "@/lib/leadAnswer";
import BreadcrumbsUI from "@/components/shared/BreadcrumbsUI";
import { SectionBlocks } from "@/components/shared/ContentBlocks";
import { FAQItem } from "@/components/shared/FaqSection";
import CTASection from "@/components/shared/CTASection";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: "easeOut" as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const SERVICE_META: Record<string, { title: string; description: string; image: string }> = {
  "lincoln/computer-recycling": {
    title: "Computer Recycling Lincoln, NE | Precision E-Cycle",
    description: "Certified laptop and desktop recycling in Lincoln, NE, with NIST 800-88 data destruction, serialized Certificate of Destruction, and free bulk pickup for qualifying volumes.",
    image: "/images/og-lincoln-computer-recycling.png",
  },
  "lincoln/server-disposal": {
    title: "Server Disposal Lincoln, NE | Precision E-Cycle",
    description: "Data center decommissioning and server disposal in Lincoln, NE, with applicable material routed to R2-certified downstream processors. Chain-of-custody practices and NIST 800-88-informed options may be available as applicable.",
    image: "/images/og-lincoln-server-disposal.png",
  },
  "lincoln/data-destruction": {
    title: "Data Destruction Lincoln, NE | Precision E-Cycle",
    description: "NIST 800-88-informed data-processing options in Lincoln, NE. Applicable processing documentation may be available for accepted equipment, with on-site drop-off available.",
    image: "/images/og-lincoln-data-destruction.png",
  },
  "omaha/computer-recycling": {
    title: "Computer Recycling Omaha, NE | Precision E-Cycle",
    description: "Free bulk computer and laptop recycling pickup in Omaha, NE. NIST 800-88 data destruction and Certificate of Destruction included for qualifying volumes.",
    image: "/images/og-omaha-computer-recycling.png",
  },
  "omaha/server-disposal": {
    title: "Server Disposal Omaha, NE | Precision E-Cycle",
    description: "Enterprise server decommissioning and certified disposal for Omaha-area organizations. Full chain-of-custody and NIST 800-88 data destruction included.",
    image: "/images/og-omaha-server-disposal.png",
  },
  "omaha/data-destruction": {
    title: "Data Destruction Omaha, NE | Precision E-Cycle",
    description: "NIST 800-88-informed data-processing options for Omaha-area businesses. Applicable documentation and chain-of-custody practices may be available for accepted equipment.",
    image: "/images/og-omaha-data-destruction.png",
  },
};

const SERVICE_ICONS: Record<string, typeof Shield> = {
  "computer-recycling": Truck,
  "server-disposal": Shield,
  "data-destruction": FileText,
  medical: HeartPulse,
  finance: Banknote,
  government: Landmark,
  education: GraduationCap,
  "server-recycling": Server,
  "hard-drive-wiping": HardDrive,
  "mobile-shredding": Scissors,
  degaussing: Zap,
  "laptop-recycling": Laptop,
};

const SERVICE_LABELS: Record<string, string> = {
  "computer-recycling": "Computer Recycling",
  "server-disposal": "Server Disposal",
  "data-destruction": "Data Destruction",
  medical: "Healthcare",
  finance: "Financial Services",
  government: "Government",
  education: "Education",
  "server-recycling": "Server Recycling",
  "hard-drive-wiping": "Hard Drive Wiping",
  "mobile-shredding": "Mobile Shredding",
  degaussing: "Degaussing",
  "laptop-recycling": "Laptop Recycling",
};

export default function CityServicePage() {
  const params = useParams<{ city: string; service: string }>();
  const city = params.city ?? "";
  const service = params.service ?? "";
  const key = `${city}/${service}`;
  const data = factoryReviewCityServiceData[key] ?? cityServiceData[key] ?? nicheSpokeData[key] ?? methodSpokeData[key];

  if (!data) {
    return (
      <div className="py-32 text-center">
        <h1 className="font-['Poppins'] font-bold text-3xl text-[#1D4394] mb-4">Page Not Found</h1>
        <p className="text-gray-400 text-sm mb-6">We don't have a page for that location and service combination.</p>
        <Link href="/locations" className="text-[#00AEEF] hover:underline font-semibold text-sm">
          Browse all locations
        </Link>
      </div>
    );
  }

  const pmEntry = pageMeta[`/locations/${city}/${service}` as PageMetaRoute];
  const availabilityConfirmationRequired = data.availabilityConfirmationRequired === true;
  const meta = factoryReviewCityServiceData[key]
    ? { title: data.seoTitle ?? data.heroH1, description: data.seoDescription ?? data.heroSubheadline, image: data.heroImage }
    : SERVICE_META[key] ??
      (pmEntry ? { title: pmEntry.title, description: pmEntry.description, image: pmEntry.image ?? "" } : undefined);
  const ServiceIcon = SERVICE_ICONS[service] ?? Shield;

  const breadcrumbLabel = SERVICE_LABELS[service] ?? service;

  // Use the shared builder rather than a hand-copied variant, so the GEO
  // lead answer has exactly one definition across every template.
  const leadAnswer = buildCityLeadAnswer(data.city, data.state);

  const breadcrumbs = makeBreadcrumbs([
    { name: "Home", url: "/" },
    { name: "Locations", url: "/locations" },
    { name: `${data.city}, ${data.state}`, url: `/locations/${data.citySlug}` },
    { name: breadcrumbLabel, url: `/locations/${data.citySlug}/${data.serviceSlug}` },
  ]);

  const serviceSchema = makeService(
    data.serviceName,
    data.serviceSchemaDescription,
    `/locations/${data.citySlug}/${data.serviceSlug}`,
    data.serviceSlug
     .split("-")
     .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
     .join(" "),
  );

  const faqSchema = makeFAQPage(data.faqs);

  const howToSchema = data.howTo
    ? makeHowTo(
        data.howTo.name,
        data.howTo.description,
        data.process.map((p) => ({ name: p.title, text: p.desc })),
      )
    : null;

  return (
    <div className="bg-white" data-testid={`city-service-page-${key.replace("/", "-")}`}>
      {meta && <PageMeta title={meta.title} description={meta.description} image={meta.image} />}
      <SchemaScript schema={breadcrumbs} id={`schema-${key.replace("/", "-")}-breadcrumbs`} />
      <SchemaScript schema={serviceSchema} id={`schema-${key.replace("/", "-")}-service`} />
      <SchemaScript schema={faqSchema} id={`schema-${key.replace("/", "-")}-faq`} />
      {howToSchema && (
        <SchemaScript schema={howToSchema} id={`schema-${key.replace("/", "-")}-howto`} />
      )}

      {/* HERO */}
      <section className="relative min-h-[340px] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={data.heroImage}
            alt={data.heroH1}
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1f54]/96 via-[#1D4394]/90 to-[#1D4394]/60" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }} className="max-w-2xl">
            <BreadcrumbsUI items={[{ name: "Home", url: "/" }, { name: "Locations", url: "/locations" }, { name: `${data.city}, ${data.state}`, url: `/locations/${data.citySlug}` }, { name: breadcrumbLabel, url: `/locations/${data.citySlug}/${data.serviceSlug}` }]} />
            <div className="inline-flex items-center gap-2 bg-[#00AEEF]/15 border border-[#00AEEF]/30 rounded-full px-4 py-1.5 mb-5">
              <Award size={13} className="text-[#00AEEF]" />
              <span className="text-[#00AEEF] text-xs font-semibold tracking-widest uppercase">{data.heroBadge}</span>
            </div>
            <h1 className="text-4xl font-bold text-white font-['Poppins'] mb-4 leading-tight">{data.heroH1}</h1>
            <p className="text-blue-100 text-base leading-relaxed mb-7 max-w-xl">{data.heroSubheadline}</p>
            <div className="flex flex-wrap gap-3">
              <Link
                href={availabilityConfirmationRequired ? "/contact" : "/schedule-pickup"}
                className="inline-flex items-center gap-2 bg-[#00AEEF] hover:bg-[#0099d4] text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition-colors"
                data-testid={`link-schedule-hero-${key.replace("/", "-")}`}
              >
                <Truck size={15} />
                {availabilityConfirmationRequired ? "Request Project Review" : "Schedule a Pickup"}
              </Link>
              <a
                href={siteConfig.contact.phonePrimaryHref}
                className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/30 text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition-colors"
              >
                <Phone size={15} />
                {siteConfig.contact.phonePrimary}
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* INCLUDED STRIP */}
      <section className="bg-[#0d2154] border-b border-[#1D4394]/40 py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {data.includes.map((item) => (
              <div key={item} className="flex items-center gap-2">
                <CheckCircle size={12} className="text-[#00AEEF] shrink-0" />
                <span className="text-blue-100 text-xs font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INTRO + SIDEBAR */}
      <section className="section-standard bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <div className="grid lg:grid-cols-5 gap-10">

              {/* LEFT: content */}
              <motion.div variants={fadeUp} className="lg:col-span-3 space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-[#1D4394] font-['Poppins'] mb-4">{data.introHeading}</h2>
                  <p className="text-gray-600 text-sm leading-relaxed mb-3">{leadAnswer}</p>
                  <p className="text-gray-600 text-sm leading-relaxed mb-3">{data.introP1}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{data.introP2}</p>
                </div>

                {/* Benefits */}
                <div>
                  <h2 className="text-lg font-bold text-[#1D4394] font-['Poppins'] mb-4">{data.benefitsHeading}</h2>
                  <div className="space-y-4">
                    {data.benefits.map(({ title, desc }) => (
                      <div key={title} className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#1D4394]/10 flex items-center justify-center shrink-0 mt-0.5">
                          <ServiceIcon size={14} className="text-[#1D4394]" />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800 text-sm mb-0.5">{title}</p>
                          <p className="text-gray-500 text-xs leading-relaxed">{desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* RIGHT: sidebar */}
              <motion.div variants={fadeUp} className="lg:col-span-2 space-y-5">
                {/* CTA Card */}
                <div className="bg-[#1D4394] rounded-xl p-6 text-white">
                  <p className="text-[#00AEEF] font-semibold text-xs uppercase tracking-wide mb-3">
                    {availabilityConfirmationRequired ? "Project Review" : "Request Service"}
                  </p>
                  <h3 className="font-bold text-lg font-['Poppins'] mb-2">
                    {availabilityConfirmationRequired ? "Planning a Project?" : "Ready to Recycle?"}
                  </h3>
                  <p className="text-blue-200 text-sm leading-relaxed mb-5">
                    {availabilityConfirmationRequired
                      ? "Send the project scope for an availability and requirements review."
                      : "Schedule a pickup or contact us with questions. We respond promptly."}
                  </p>
                  <div className="space-y-2.5">
                    <Link
                      href={availabilityConfirmationRequired ? "/contact" : "/schedule-pickup"}
                      className="w-full flex items-center justify-center gap-2 bg-[#00AEEF] hover:bg-[#0099d4] text-white font-semibold py-2.5 rounded-xl text-sm transition-colors"
                    >
                      <Truck size={15} />
                      {availabilityConfirmationRequired ? "Request Project Review" : "Schedule a Pickup"}
                    </Link>
                    <Link
                      href="/contact"
                      className="w-full flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold py-2.5 rounded-xl text-sm transition-colors"
                    >
                      Send a Message
                    </Link>
                  </div>
                </div>

                {/* Related services */}
                <div className="bg-gray-50 rounded-xl p-5 border border-gray-100">
                  <p className="font-semibold text-gray-800 text-sm mb-3">Related Services</p>
                  <div className="space-y-2">
                    {data.relatedServices.map(({ label, href }) => (
                      <Link
                        key={href}
                        href={href}
                        className="flex items-center justify-between text-xs text-[#1D4394] hover:text-[#00AEEF] font-medium py-1.5 border-b border-gray-100 last:border-0 transition-colors"
                      >
                        {label}
                        <ArrowRight size={12} />
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Phone */}
                <div className="bg-gray-50 rounded-xl p-5 border border-gray-100">
                  <p className="font-semibold text-gray-800 text-sm mb-2">Prefer to call?</p>
                  <p className="text-gray-500 text-xs leading-relaxed mb-3">
                    Mon-Fri 8:00 AM to 5:00 PM CST.
                  </p>
                  <a href={siteConfig.contact.phonePrimaryHref} className="inline-flex items-center gap-2 text-[#00AEEF] font-semibold text-sm hover:underline">
                    <Phone size={13} />
                    {siteConfig.contact.phonePrimary}
                  </a>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="section-standard bg-gray-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.div variants={fadeUp} className="mb-8">
              <span className="text-[#00AEEF] font-semibold text-sm uppercase tracking-widest mb-2 block">How It Works</span>
              <h2 className="text-2xl font-bold text-[#1D4394] font-['Poppins']">{data.processHeading}</h2>
            </motion.div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {data.process.map(({ step, title, desc }) => (
                <motion.div key={step} variants={fadeUp} className="bg-white rounded-xl p-6 border border-gray-100 hover:border-[#00AEEF]/30 hover:shadow-sm transition-all">
                  <span className="font-black text-[#00AEEF]/40 text-3xl font-['Poppins'] leading-none block mb-4">{step}</span>
                  <h3 className="font-bold text-[#1D4394] text-sm mb-2 font-['Poppins']">{title}</h3>
                  <p className="text-gray-500 text-xs leading-relaxed">{desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* EXPANDED CONTEXT */}
      {data.expandedSections && data.expandedSections.length > 0 && (
        <section className="section-standard bg-white border-t border-gray-100">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
            {data.expandedSections.map((section, idx) => (
              <motion.div
                key={section.heading}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: idx * 0.05 }}
              >
                <h2 className="text-xl font-bold text-[#1D4394] font-['Poppins'] mb-4">{section.heading}</h2>
                <SectionBlocks section={section} />
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* FAQ */}
      <section className="section-standard bg-white border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.div variants={fadeUp} className="mb-8 text-center">
              <span className="text-[#00AEEF] font-semibold text-sm uppercase tracking-widest mb-2 block">FAQ</span>
              <h2 className="text-2xl font-bold text-[#1D4394] font-['Poppins']">{data.faqHeading}</h2>
            </motion.div>
            <motion.div variants={fadeUp} className="space-y-3">
              {data.faqs.map((faq) => (
                <FAQItem key={faq.question} question={faq.question} answer={faq.answer} />
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      <CTASection
        eyebrow={availabilityConfirmationRequired ? "Project Review" : "Request Service"}
        title={availabilityConfirmationRequired ? `Planning a Project in ${data.city}?` : `Ready to Get Started in ${data.city}?`}
        description={
          availabilityConfirmationRequired
            ? "Send the project scope for an availability and requirements review."
            : "Schedule a pickup or send us a message and we will respond promptly."
        }
        primaryButton={
          availabilityConfirmationRequired
            ? { label: "Request Project Review", href: "/contact" }
            : { label: "Schedule a Pickup", href: "/schedule-pickup" }
        }
        secondaryButton={{ label: "Contact Us", href: "/contact" }}
      />
    </div>
  );
}
