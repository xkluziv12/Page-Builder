import type { ExpandedSection } from "../lib/contentBlocks";
// City+Service combination page data.
// Each key is "{citySlug}/{serviceSlug}", drives CityServicePage.tsx.

export interface CityServiceFAQ {
  question: string;
  answer: string;
}

export interface CityServiceStep {
  step: string;
  title: string;
  desc: string;
}

export interface CityServiceBenefit {
  title: string;
  desc: string;
}

export interface RelatedLink {
  label: string;
  href: string;
}

export type CityServiceExpandedSection = ExpandedSection;

export interface CityServiceData {
  city: string;
  state: string;
  citySlug: string;
  serviceSlug: string;
  /** Factory records carry page metadata with the content artifact. */
  seoTitle?: string;
  seoDescription?: string;
  heroBadge: string;
  heroH1: string;
  heroSubheadline: string;
  heroImage: string;
  introHeading: string;
  introP1: string;
  introP2: string;
  includes: string[];
  processHeading: string;
  process: CityServiceStep[];
  benefitsHeading: string;
  benefits: CityServiceBenefit[];
  faqHeading: string;
  faqs: CityServiceFAQ[];
  relatedServices: RelatedLink[];
  serviceName: string;
  serviceSchemaDescription: string;
  /** Code-owned market posture. Generated records may not decide this value. */
  availabilityConfirmationRequired?: boolean;
  /**
   * Optional HowTo schema. When present, CityServicePage emits a HowTo JSON-LD
   * node built from the `process` steps (step title -> HowToStep name, step
   * desc -> text). Used by Tier 3 method/equipment spokes where the page
   * describes a genuine step-by-step process. Legacy and niche pages omit it
   * so their existing schema output is unchanged.
   */
  howTo?: { name: string; description: string };
  /**
   * Optional deeper-context sections rendered between the process grid
   * and the FAQ. Used to add page-specific compliance framing and local
   * service depth without inflating the hero or intro blocks. Each
   * section becomes its own visual block on the rendered page.
   */
  expandedSections?: CityServiceExpandedSection[];
}

export const cityServiceData: Record<string, CityServiceData> = {

  // ────────────────────────────────────────────────────────────────────────────
  // LINCOLN, COMPUTER RECYCLING
  // ────────────────────────────────────────────────────────────────────────────
  "lincoln/computer-recycling": {
    city: "Lincoln",
    state: "NE",
    citySlug: "lincoln",
    serviceSlug: "computer-recycling",
    heroBadge: "Lincoln, NE",
    heroH1: "Computer Recycling Lincoln, NE",
    heroSubheadline:
       "Certified laptop and desktop recycling at our Lincoln processing facility. Drop off or schedule a free bulk pickup for qualifying volumes; NIST 800-88-informed processing options and applicable documentation may be available based on confirmed scope.",
    heroImage: "/images/computer-recycling-hero.png",
    introHeading: "Lincoln's Local Computer Recycling Facility",
    introP1:
      "Precision E-Cycle operates a local electronics processing facility, located at 4100 Industrial Ave STE D. Whether your organization has five aging laptops or five hundred end-of-life workstations, we can coordinate the confirmed disposition scope under one roof, including intake and data processing, with applicable recovered material routed to R2-certified downstream processors.",
    introP2:
      "Lincoln businesses use us to coordinate IT refresh cycles. Accepted computers, laptops, and desktops can receive serial-level documentation and data-processing methods informed by NIST 800-88 before applicable downstream processing begins. Where downstream partners are involved, the confirmed chain-of-custody scope identifies the relevant handoffs and records.",
    includes: [
      "Free bulk pickup for qualifying volumes (qualifying volumes, Lincoln area)",
       "NIST 800-88-informed processing for eligible data-bearing media",
       "Applicable serialized documentation where included in scope",
      "Asset manifest with make, model, and serial number",
      "Routing to R2-certified downstream processors",
      "Drop-off available Mon-Fri, no appointment needed",
    ],
    processHeading: "How Lincoln Computer Recycling Works",
    process: [
      {
        step: "01",
        title: "Schedule or Drop Off",
        desc: "Submit a pickup request online or drop your equipment directly at 4100 Industrial Ave STE D. We confirm promptly.",
      },
      {
        step: "02",
        title: "Intake and Inventory",
         desc: "Accepted equipment is logged by make, model, and serial number on arrival where the confirmed service scope calls for serialized intake. We explain the available manifest before processing begins.",
      },
      {
        step: "03",
        title: "NIST-Compliant Data Destruction",
         desc: "Eligible data-bearing media may be processed using methods informed by NIST SP 800-88 Rev. 1, including software wipe, degaussing, or physical shredding based on device type and confirmed requirements.",
      },
      {
        step: "04",
        title: "Certificate of Destruction",
         desc: "Applicable processing documentation, including a serialized COD where included in scope, may be delivered digitally for your records.",
      },
    ],
    benefitsHeading: "Why Lincoln Organizations Choose Precision E-Cycle",
    benefits: [
      {
        title: "On-Site Facility, No Shipping Required",
         desc: "Confirmed Lincoln engagements can be processed at our local plant rather than sent to an unknown facility. Any downstream routing is discussed as part of the accepted service scope.",
      },
      {
        title: "Compliance-Ready Documentation",
         desc: "The agreed engagement may produce an asset manifest, applicable processing documentation, and chain-of-custody records for HIPAA, SOX, FERPA, or internal audit review, depending on scope.",
      },
      {
        title: "Responsive Scheduling",
        desc: "Most Lincoln-area pickups are confirmed quickly and scheduled promptly. For drop-offs, we accept equipment without an appointment Monday through Friday.",
      },
    ],
    faqHeading: "Computer Recycling in Lincoln: Common Questions",
    faqs: [
      {
        question: "Do you offer free computer recycling pickup in Lincoln, NE?",
        answer:
          "Yes. We offer free bulk pickup for organizations in Lincoln and Lancaster County with a business-scale load, or a comparable mixed load. We schedule most Lincoln pickups promptly after your request.",
      },
      {
        question: "What types of computers do you accept at your Lincoln facility?",
        answer:
           "We review desktop computers, laptops, notebooks, tablets, workstations, and all-in-one PCs at our Lincoln facility, subject to current acceptance criteria. Associated peripherals may include monitors, keyboards, mice, docking stations, and external drives.",
      },
      {
        question: "Is data destruction included with computer recycling in Lincoln?",
        answer:
           "Eligible data-bearing equipment may receive processing informed by NIST SP 800-88 Rev. 1 at no additional charge for qualifying pickups when included in the confirmed scope. Applicable serialized documentation may be provided.",
      },
      {
        question: "Do I need to remove hard drives before dropping off computers?",
        answer:
           "You can generally bring computers with drives installed, subject to acceptance criteria. Our team can review the applicable data-processing scope on-site. If you prefer to remove drives first, we can also review drive-only handling and documentation options.",
      },
    ],
    relatedServices: [
      { label: "Lincoln Electronics Recycling", href: "/locations/lincoln" },
      { label: "Server Disposal Lincoln", href: "/locations/lincoln/server-disposal" },
      { label: "Data Destruction Lincoln", href: "/locations/lincoln/data-destruction" },
      { label: "Computer Recycling Services", href: "/services/computer-recycling" },
    ],
    serviceName: "Computer Recycling, Lincoln, NE",
    serviceSchemaDescription:
       "Responsible laptop and desktop recycling in Lincoln, Nebraska, with applicable material routed to R2-certified downstream processors. NIST 800-88-informed processing and applicable documentation may be available for eligible accepted equipment.",
    expandedSections: [
      {
        heading: "Compliance Framework for Computer and Laptop Disposal",
        paragraphs: [
           "Computer recycling at the business level sits at the intersection of two regulatory regimes. The first is data sanitization. Laptops, desktops, and workstations may contain one or more storage devices, including NVMe drives, eMMC chips, removable drives, and other embedded media. NIST Special Publication 800-88 Revision 1 is the federal standard for media sanitization and defines three method tiers: Clear (logical overwrite), Purge (cryptographic erasure or block-level overwrite verified to be unrecoverable), and Destroy (physical destruction such as shredding). Eligible media may be evaluated for a Purge or Destroy method based on media type and confirmed requirements, with the applicable method documented where the service scope includes that record.",
           "The second regime is downstream environmental compliance. The R2 downstream (Responsible Recycling) standard, currently at version R2v3, addresses material tracking and audited downstream vendors. Precision E-Cycle does not hold R2 facility certification, but may route applicable downstream material through R2-certified processors and smelters who meet the relevant requirements and undergo independent third-party auditing. For computer recycling, batteries, circuit boards, plastics, and other streams are evaluated for appropriate downstream handling. The agreed engagement may include an asset manifest and downstream summary where those records are part of the confirmed scope.",
          "For organizations subject to industry-specific frameworks (HIPAA for covered entities and business associates, GLBA and FACTA for financial services, FERPA for educational institutions, SOX for public companies, FISMA for federal contractors), the same documentation supports those audits. The COD format is designed to satisfy the most stringent of these without the client having to translate between standards.",
        ],
      },
      {
        heading: "Computer Recycling for Lincoln Organizations",
        paragraphs: [
          "Lincoln supports a concentrated mix of state government, higher education, healthcare, and financial services that drive predictable computer refresh cycles. The State of Nebraska, the University of Nebraska-Lincoln, Lincoln Public Schools, Bryan Health, and the financial institutions clustered along O Street and downtown all manage fleets that turn over on three to five year intervals. Precision E-Cycle works with IT and procurement teams in these organizations to coordinate scheduled pickups that line up with internal asset retirement windows rather than forcing the organization to stage equipment for an extended period.",
          "Our Lincoln facility at 4100 Industrial Ave is the operational hub for the entire 500-mile service radius, which means Lincoln pickups have the shortest scheduling window and the most flexibility on volume. Prompt scheduling is the norm for qualifying business volumes, and walk-in drop-off at the facility is available during business hours for smaller quantities. For large refreshes the planning conversation usually starts a few weeks ahead so we can stage the right transport and confirm any documentation requirements specific to the organization.",
        ],
      },
      {
        heading: "What to Expect on Pickup Day in Lincoln",
        paragraphs: [
          "A Lincoln pickup typically opens with a brief on-site walkthrough so our technician can confirm the staging area, the access path, and any equipment that was added or removed since the original scope was set. Devices are scanned in by serial number against the pickup manifest the client signs at the door. For larger pickups we bring pallet jacks, gaylords, and dollies sized to the volume rather than asking the client to pre-stage equipment in any specific way.",
          "Once equipment is loaded, the chain-of-custody log closes out at the loading dock with both signatures, and the documentation package starts moving in parallel with the physical transport. Devices arrive at our processing facility promptly for Lincoln pickups, and intake processing typically begins shortly thereafter. Standard Certificates of Destruction are delivered promptly after processing, and the asset manifest, downstream summary, and any client-specific compliance documents follow shortly after as a single consolidated package.",
        ],
      },
    ],
  },

  // ────────────────────────────────────────────────────────────────────────────
  // LINCOLN, SERVER DISPOSAL
  // ────────────────────────────────────────────────────────────────────────────
  "lincoln/server-disposal": {
    city: "Lincoln",
    state: "NE",
    citySlug: "lincoln",
    serviceSlug: "server-disposal",
    heroBadge: "Lincoln, NE",
    heroH1: "Server Disposal Lincoln, NE",
    heroSubheadline:
      "Data center decommissioning and server recycling at our Lincoln, Nebraska facility, with applicable material routed to R2-certified downstream processors. Full chain-of-custody documentation and NIST 800-88 compliant data destruction included.",
    heroImage: "/images/server-disposal-hero.png",
    introHeading: "Lincoln Server Disposal and Data Center Decommissioning",
    introP1:
      "Precision E-Cycle handles server disposal and data center decommissions for organizations across Lincoln and the surrounding region from our processing facility at 4100 Industrial Ave STE D. We accept rack servers, blade servers, tower servers, UPS units, network switches, SAN arrays, and associated data center hardware, all processed under a single chain of custody.",
    introP2:
      "Server decommissions demand documentation that holds up under audit. Every engagement we conduct in Lincoln produces a serial-level asset manifest logged before equipment leaves your floor, NIST 800-88 compliant data destruction for every drive, and a Certificate of Destruction delivered promptly. Your compliance team gets exactly what they need.",
    includes: [
      "Free pickup for qualifying server volumes",
      "NIST 800-88 data destruction on all drives and storage",
      "Serialized Certificate of Destruction per device",
      "Serial-level asset manifest before equipment is moved",
      "Applicable routing to R2-certified downstream processors",
      "Chain-of-custody records archived for your compliance records",
    ],
    processHeading: "How Lincoln Server Disposal Works",
    process: [
      {
        step: "01",
        title: "Submit a Decommission Request",
        desc: "Tell us what you have, server count, rack units, and any access requirements. We respond promptly with scheduling and logistics options.",
      },
      {
        step: "02",
        title: "On-Site Inventory at Your Location",
        desc: "Our team arrives with intake sheets and logs every server by make, model, and serial number before any device is moved from your floor.",
      },
      {
        step: "03",
        title: "Secure Transport to Our Lincoln Facility",
        desc: "Equipment is transported to our Lincoln processing facility in a secured vehicle with full chain-of-custody maintained throughout.",
      },
      {
        step: "04",
        title: "Data Destruction and Documentation",
        desc: "All storage media is sanitized per NIST 800-88. You receive a serialized COD for every data-bearing device promptly.",
      },
    ],
    benefitsHeading: "Why Lincoln Organizations Trust Us for Server Disposal",
    benefits: [
      {
        title: "Full Chain-of-Custody Documentation",
        desc: "From the moment our crew logs your servers on your floor to final certification, every step is documented and available for your compliance or audit records.",
      },
      {
        title: "R2-Certified Downstream Processors",
        desc: "All material is routed to R2-certified downstream processors and smelters with third-party auditing. Downstream vendor documentation is available upon request for your ITAD compliance package.",
      },
      {
        title: "Any Volume, Any Configuration",
        desc: "We handle one server or a full rack room. If your decommission requires after-hours access or phased removal over multiple days, we work around your schedule.",
      },
    ],
    faqHeading: "Server Disposal in Lincoln: Common Questions",
    faqs: [
      {
        question: "Do you pick up servers from Lincoln businesses and data centers?",
        answer:
          "Yes. We handle server pickups and full data center decommissions for organizations across Lincoln and Lancaster County. We schedule most Lincoln pickups promptly and can accommodate after-hours or weekend access for large decommissions.",
      },
      {
        question: "What types of servers do you accept?",
        answer:
          "We accept rack-mount servers, blade servers, tower servers, and associated data center hardware including network switches, SAN arrays, UPS units, PDUs, and cabling. We process all major brands including Dell, HP, IBM, Cisco, and SuperMicro.",
      },
      {
        question: "What data destruction documentation do you provide for server disposal?",
        answer:
          "We provide a serial-level asset manifest listing every device by make, model, and serial number, and a Certificate of Destruction for every data-bearing device. Both documents are delivered digitally promptly after processing and are suitable for HIPAA, SOX, FERPA, and NIST audit requirements.",
      },
      {
        question: "Can you handle a full data center decommission from a Lincoln facility?",
        answer:
          "Yes. We have handled decommissions ranging from single-rack removals to multi-room data center clearances. Contact us with your equipment count and we will provide a scope, timeline, and logistics plan.",
      },
      {
        question: "The server will not power on. Is the data still recoverable?",
        answer:
          "Assume yes. A chassis that fails to POST tells you nothing about the state of the drives inside it, because the failure is usually a power supply, a board, or a backplane rather than the storage. The platters or NAND are typically intact and readable once a drive is moved to working hardware, which is exactly what a recovery lab does. A dead server is a data-bearing asset until each drive inside it has been sanitized and documented individually.",
      },
      {
        question: "We already pulled the drives. Is anything else in the chassis data-bearing?",
        answer:
          "Often yes, and this is where server decommissions leak. Out-of-band management controllers such as iDRAC, iLO, and generic BMCs hold configuration, credentials, and log data in their own flash. RAID controllers carry cache modules. Boot media can be an internal SD card or an M.2 device seated outside the drive bays entirely. We inventory these alongside the main drives rather than treating empty bays as proof the chassis is clean.",
      },
      {
        question: "How do you handle servers still under lease or support contract?",
        answer:
          "We work to the return condition your agreement specifies. Some lessors require the chassis returned intact with drives removed and destroyed separately, others accept a sanitized drive left in place with documentation. Tell us which applies before the pickup is scoped, because the two paths produce different paperwork and are not interchangeable after the fact. Either way you receive per-device documentation you can attach to the lease return file.",
      },
    ],
    relatedServices: [
      { label: "Lincoln Electronics Recycling", href: "/locations/lincoln" },
      { label: "Computer Recycling Lincoln", href: "/locations/lincoln/computer-recycling" },
      { label: "Data Destruction Lincoln", href: "/locations/lincoln/data-destruction" },
      { label: "Server Disposal Services", href: "/services/server-disposal" },
    ],
    serviceName: "Server Disposal, Lincoln, NE",
    serviceSchemaDescription:
       "Data center decommissioning and server disposal in Lincoln, Nebraska, with applicable material routed to R2-certified downstream processors. NIST 800-88 data destruction and chain-of-custody documentation for every engagement.",
    expandedSections: [
      {
        heading: "Compliance Framework for Server and Data Center Decommission",
        paragraphs: [
          "Server disposal differs from desktop and laptop recycling in three ways: scale, complexity, and the concentration of sensitive data on each chassis. A single 2U server can hold a dozen or more drives in a RAID configuration, and a half-populated rack can carry more storage than an entire department of laptops. NIST 800-88 Rev. 1 applies to every one of those drives, and our chain-of-custody documentation captures each drive at the serial level rather than at the chassis level. RAID striping does not reduce the obligation. Each constituent drive is sanitized using the method appropriate to its media type, and the Certificate of Destruction lists each drive separately even when they shipped together in one host.",
          "Data center decommissions add a logistics layer on top of the destruction obligation. Cabinets need to be powered down in a controlled sequence, network and power cables traced and removed, rails released, and units palletized for transport without dropping or damaging media. Precision E-Cycle coordinates these projects with the on-site IT or facilities team, schedules pickups around production windows, and provides asset-level scan-in receipts the moment equipment leaves the building. For colocation tenants who do not own the cage, we coordinate directly with the data center operator on access, escort, and load-out documentation so the tenant satisfies their lease exit requirements.",
          "Witnessed destruction is available on-site for clients whose policies prohibit data-bearing media from leaving their premises in any state other than physically destroyed. In that workflow, our technician brings shredding equipment to the facility, performs destruction in front of a designated client representative, and issues the COD on the spot before equipment leaves with us as scrap. This pattern is common for clients managing classified workloads, financial trading systems, and certain healthcare deployments.",
        ],
      },
      {
        heading: "Server Disposal for Lincoln Data Centers and Server Rooms",
        paragraphs: [
          "Server-grade disposal in Lincoln spans three patterns: in-house server rooms operated by mid-sized organizations, colocation tenants in regional data centers, and the on-premises infrastructure still maintained by state agencies and the university system. Each pattern has its own documentation expectations. In-house rooms typically need a clean inventory hand-off and Certificates of Destruction for each drive. Colocation tenants need cage clearance documentation that satisfies the data center operator. State and university workflows often require procurement-aligned vendor records and asset-level disposition reports filed back into internal asset management systems.",
          "Precision E-Cycle handles all three patterns from our Lincoln facility, which keeps logistics tight and lets us schedule decommissions on short notice when a project window opens up. For tenant move-outs and full-rack retirements we provide on-site technicians, palletization, and scan-out documentation the moment equipment leaves the floor.",
        ],
      },
      {
        heading: "Lincoln Decommission Logistics",
        paragraphs: [
          "Server work in Lincoln benefits from being close to our processing facility, which means decommission projects can be scoped and scheduled more flexibly than longer-distance engagements. For full-rack and multi-rack retirements we coordinate with the on-site team on power-down sequencing, cable management, rail removal, and palletization in advance so the actual on-site time stays compact. For owner-occupied server rooms, on-site work is typically completed in a single visit. For colocation tenants we coordinate the cage access, escort scheduling, and load-out documentation directly with the data center operator.",
          "Documentation deliverables for Lincoln server engagements include the per-drive Certificates of Destruction, the asset-level inventory tied to the original chassis serial numbers, the chain-of-custody log from on-site through processing, and any operator-specific or client-specific compliance documents that the engagement scope required. The full package lands within the timeline agreed during scoping rather than as an open-ended delivery.",
          "Engagement scoping for Lincoln server work is a written conversation rather than a verbal estimate, and the documentation deliverable schedule is committed in writing before the engagement starts so the internal IT team and procurement team have the same expectations on timing.",
        ],
      },
      {
        heading: "What a Lincoln Decommission Actually Produces on Paper",
        paragraphs: [
          "The deliverable from a server decommission is not a receipt, it is an evidence package, and it is worth knowing what belongs in one before comparing vendors. Each data-bearing device gets its own Certificate of Destruction recording the make, model, serial number, capacity, media type covering hard disk, solid state, NVMe, optical, tape, and mobile, the destruction method applied, the operator initials, the date and time, and a reference number tying back to the chain-of-custody log signed at your dock.",
          "Alongside that sits an itemized asset manifest covering the full chassis inventory rather than the drives alone, and downstream processing records showing where recovered material went. For organizations retiring equipment under lease, that package closes the return file. For organizations under HIPAA 45 CFR 164.310(d), the Gramm-Leach-Bliley Safeguards Rule, or Nebraska state procurement standards referencing NIST 800-88, it is the evidence a reviewer asks for by name.",
          "The failure mode to watch for is aggregation. A vendor that issues one certificate for an entire rack, or reports disposal by weight, has produced a document that cannot answer a question about a specific asset. That is adequate right up until an auditor names a serial number, at which point it is worth nothing.",
        ],
      },
    ],
  },

  // ────────────────────────────────────────────────────────────────────────────
  // LINCOLN, DATA DESTRUCTION
  // ────────────────────────────────────────────────────────────────────────────
  "lincoln/data-destruction": {
    city: "Lincoln",
    state: "NE",
    citySlug: "lincoln",
    serviceSlug: "data-destruction",
    heroBadge: "Lincoln, NE",
    heroH1: "Data Destruction Lincoln, NE",
    heroSubheadline:
      "NIST 800-88 compliant data destruction for hard drives, SSDs, and servers at our Lincoln processing facility. Certificate of Destruction issued for every device.",
    heroImage: "/images/data-destruction-hero.png",
    introHeading: "Certified Data Destruction in Lincoln, Nebraska",
    introP1:
      "Precision E-Cycle performs NIST SP 800-88 Rev. 1 compliant data destruction at our processing facility in Lincoln. We sanitize hard disk drives, SSDs, NVMe drives, magnetic tape, and mobile storage using software-based wipe, degaussing, or physical shredding, matched to the media type and your compliance requirements.",
    introP2:
      "Lincoln organizations in healthcare, government, finance, and education rely on our documented destruction process to satisfy HIPAA, SOX, FERPA, GLBA, and NIST audit requirements. Every engagement produces a serialized Certificate of Destruction that identifies each device by serial number and destruction method, suitable for regulator review.",
    includes: [
      "NIST SP 800-88 Rev. 1 compliant destruction",
      "Serialized Certificate of Destruction per device",
      "Software wipe, degaussing, or physical shredding",
      "All media types: HDD, SSD, NVMe, tape, mobile",
      "Chain-of-custody from intake through certification",
      "Records archived for your compliance records",
    ],
    processHeading: "Our Lincoln Data Destruction Process",
    process: [
      {
        step: "01",
        title: "Schedule or Drop Off",
        desc: "Schedule a pickup or bring drives directly to 4100 Industrial Ave STE D. We accept drives with or without the parent device.",
      },
      {
        step: "02",
        title: "Intake and Serial Logging",
        desc: "Every drive or device is logged by serial number and model before destruction begins. You receive a copy of the intake record.",
      },
      {
        step: "03",
        title: "Destruction by NIST Method",
        desc: "Each piece of media is destroyed using the NIST 800-88 method appropriate for its type, software wipe for re-use-eligible drives, degaussing or shredding for end-of-life media.",
      },
      {
        step: "04",
        title: "Certificate Issued Promptly",
        desc: "A serialized COD identifying each device by serial number, destruction method, and date is delivered digitally promptly.",
      },
    ],
    benefitsHeading: "Why Lincoln Organizations Choose Our Data Destruction",
    benefits: [
      {
        title: "NIST 800-88 Compliant",
        desc: "Our process follows NIST SP 800-88 Rev. 1 guidelines exactly. The COD we issue specifies the media type, destruction method, and the NIST standard applied for each device.",
      },
      {
        title: "Compliance Across Frameworks",
        desc: "HIPAA, SOX, FERPA, GLBA, FACTA, and Nebraska data security statutes all require documented destruction. Our COD satisfies all of them from a single engagement.",
      },
      {
        title: "On-Site Lincoln Facility",
        desc: "Your data never travels out of state to an unknown facility. We perform all destruction at our Lincoln plant and provide facility tour access upon request.",
      },
    ],
    faqHeading: "Data Destruction in Lincoln: Common Questions",
    faqs: [
      {
        question: "What data destruction methods do you use in Lincoln?",
        answer:
          "Method is chosen by media type, not applied uniformly. Magnetic hard drives are overwritten and verified at NIST 800-88 Purge level, or shredded where the client requires Destroy. Solid-state media is cryptographically erased using the drive's Secure Erase or Sanitize command. Backup tape and optical media are physically destroyed. Whichever method is applied to a given device is recorded against that device's serial number on the Certificate of Destruction.",
      },
      {
        question: "Does degaussing work on solid-state drives?",
        answer:
          "No, and this is one of the most costly misconceptions in device disposal. Degaussing works by disrupting a magnetic field, which is why it is effective on spinning hard drives and backup tape. Solid-state drives store data in NAND flash cells with no magnetic component, so a degausser passes over them with no effect whatsoever. An organization that degausses a mixed load and files the paperwork has destroyed some of its data and none of the rest.",
      },
      {
        question: "Isn't full-disk encryption enough on its own?",
        answer:
          "Not by itself. Cryptographic erase is a recognized Purge method under NIST 800-88, but it only holds if the encryption was correctly implemented across the whole volume and you can demonstrate the key was destroyed. Most organizations cannot produce that evidence months later during an audit. Encryption is a strong control while a device is in service. It is not a substitute for a documented sanitization event when the device leaves.",
      },
      {
        question: "Do you issue a Certificate of Destruction for every device?",
        answer:
          "Yes, one per device, serialized rather than issued as a single summary for the lot. Each certificate records the make, model, serial number, capacity, media type covering hard disk, solid state, NVMe, optical, tape, and mobile, the destruction method applied, the operator initials, the date and time, and a reference number tying back to the chain-of-custody log signed at your site. A certificate that lists only a device count cannot answer an auditor's question about a specific asset.",
      },
      {
        question: "Can I drop off hard drives at your Lincoln facility?",
        answer:
          "Yes. Loose drives can be brought to 4100 Industrial Ave STE D during business hours. Bring them in a container you do not need returned, since we log each drive by serial number at intake and it goes straight into the queue. If you need a Certificate of Destruction, tell us at the counter so we capture your organization details against the intake record rather than processing the drives as an anonymous drop.",
      },
      {
        question: "Which compliance frameworks does your data destruction support?",
        answer:
          "The documentation is built for HIPAA 45 CFR 164.310 and 164.312, the Gramm-Leach-Bliley Safeguards Rule, the FACTA Disposal Rule, FERPA under 20 U.S.C. 1232g, and SOX and SOC 2 evidence requests. It also satisfies Nebraska state agency procurement standards that reference NIST 800-88 directly. We support your compliance program by producing the evidence. The compliance determination itself stays with your organization and its counsel.",
      },
      {
        question: "Can we witness the destruction?",
        answer:
          "Yes. Witnessed sessions can be arranged at the Lincoln facility, or coordinated at your site for organizations whose internal controls require that data-bearing media never leave the building intact. This is most common among Lancaster County healthcare and financial clients, and among state agencies operating under procurement rules that call for direct observation rather than documentary evidence alone. Tell us the volume and media types and we will scope how the session runs.",
      },
    ],
    relatedServices: [
      { label: "Lincoln Electronics Recycling", href: "/locations/lincoln" },
      { label: "Computer Recycling Lincoln", href: "/locations/lincoln/computer-recycling" },
      { label: "Server Disposal Lincoln", href: "/locations/lincoln/server-disposal" },
      { label: "Data Destruction Services", href: "/services/data-destruction" },
    ],
    serviceName: "Data Destruction, Lincoln, NE",
    serviceSchemaDescription:
      "NIST 800-88 data destruction in Lincoln, Nebraska. Certificate of Destruction issued for every device.",
    expandedSections: [
      {
        heading: "Choosing the Right Sanitization Method for the Media",
        paragraphs: [
          "NIST Special Publication 800-88 Revision 1 defines three sanitization tiers, and the difference between them is the difference between a defensible disposal and an expensive assumption. Clear is a logical overwrite that defeats casual recovery. Purge is a cryptographic erase or a verified block-level overwrite that defeats laboratory recovery. Destroy is physical destruction. The standard does not say pick one and apply it everywhere. It says match the tier to the media and to the sensitivity of what the media held.",
          "In practice that means a mixed load leaving a Lincoln office gets sorted before anything happens to it. Spinning hard drives accept a verified Purge-level overwrite, and where a client's policy calls for Destroy, they are shredded instead. Solid-state media is cryptographically erased through the drive's own Secure Erase or Sanitize command, because wear-leveling distributes writes across NAND cells in a way that makes a conventional overwrite pass unreliable even when it reports success. Backup tape, optical media, and mobile devices with soldered storage go to physical destruction because nothing else is verifiable.",
          "Any drive that fails verification is shredded rather than passed through. That rule matters more than it sounds. A verification failure is not a rare event on end-of-life hardware, and a vendor whose process has no defined path for a drive that will not verify is a vendor who is either quietly discarding it or quietly shipping it downstream intact.",
        ],
      },
      {
        heading: "Who Retires Data-Bearing Media in Lincoln, and Why It Is Different Each Time",
        paragraphs: [
          "Lincoln's data destruction volume comes from institutions whose obligations are not interchangeable. Bryan Health and CHI Health St. Elizabeth retire clinical workstations, imaging peripherals, and mobile devices that hold protected health information under HIPAA 45 CFR 164.310(d), and their disposal evidence has to survive an Office for Civil Rights review. Nelnet, Ameritas, and Assurity Life operate under the Gramm-Leach-Bliley Safeguards Rule and the FACTA Disposal Rule, where the question is whether consumer financial data was rendered unreadable and whether you can prove it.",
          "The public sector adds a third pattern. Nebraska State Capitol agencies and the Nebraska Public Power District dispose under procurement standards that reference NIST 800-88 by name, which means the method has to be nameable and the record has to be serialized before an asset can be written off. The University of Nebraska-Lincoln, Southeast Community College, and Lincoln Public Schools carry FERPA obligations under 20 U.S.C. 1232g across student device fleets that turn over on academic and budget calendars rather than continuously.",
          "The operational consequence is that a single destruction policy applied across all of them is wrong for most of them. A healthcare client and a school district can both be fully compliant and still need different tiers, different documentation depth, and different handling of devices whose storage is not obvious from the outside. We scope the method against what the media actually held rather than against what category of organization is retiring it.",
        ],
      },
      {
        heading: "Chain of Custody From Your Dock to the Certificate",
        paragraphs: [
          "The destruction step is rarely where disposal programs fail. The handoff is. Every transfer between a collector, a processor, and a downstream vendor is a point where serial-level tracking can quietly degrade into weight-level tracking, and once that happens the paperwork can no longer answer a question about a specific asset. Precision E-Cycle collects, transports, and sanitizes in one chain out of the Lincoln facility on Industrial Avenue, so the serial that comes off your asset register is the serial that appears on the certificate.",
          "Collection runs on tamper-evident containers and a manifest signed at both ends. The technician who loads the media is the technician who transports it, which removes the intermediate handling step where custody records typically break down. Media that has not yet reached intake is held in a locked secure area rather than staged on an open dock. Sanitization happens before any disassembly or downstream movement begins, so no drive leaves our control still carrying readable data.",
          "What you receive afterward is a serialized Certificate of Destruction per device, an itemized manifest, and downstream processing records showing where recovered material went. Coverage runs from Lincoln through Lancaster County and the surrounding communities including Waverly, Hickman, Bennet, Seward, York, Milford, Beatrice, and Nebraska City. Organizations with sites in more than one of our markets are handled under a single point of coordination, with documentation broken out by physical location rather than aggregated, because an auditor reviewing one site needs that site's assets.",
        ],
      },
    ],
  },

"omaha/computer-recycling": {
    city: "Omaha",
    state: "NE",
    citySlug: "omaha",
    serviceSlug: "computer-recycling",
    heroBadge: "Omaha, NE",
    heroH1: "Computer Recycling Omaha, NE",
    heroSubheadline:
      "Free bulk pickup for laptops and desktops throughout the Omaha metro area. NIST 800-88 data destruction and Certificate of Destruction included for every device.",
    heroImage: "/images/computer-recycling-hero.png",
    introHeading: "Certified Computer Recycling for Omaha-Area Organizations",
    introP1:
      "Precision E-Cycle provides free bulk computer recycling pickup for businesses, healthcare organizations, government agencies, and schools throughout the Omaha metropolitan area. Our processing facility in Lincoln processes all equipment, giving Omaha organizations access to enterprise-grade ITAD documentation without the cost of a local data destruction vendor.",
    introP2:
      "Omaha's concentration of financial institutions, healthcare networks, and government operations means data destruction documentation is rarely optional. We build the compliance package, NIST 800-88 data destruction, serialized Certificate of Destruction, and asset manifest, into every computer recycling engagement at no additional charge for qualifying volumes, arriving in a format ready for audit review.",
    includes: [
      "Free bulk pickup in the Omaha metro area",
      "NIST 800-88 data destruction on all drives",
      "Serialized Certificate of Destruction per device",
      "Asset manifest with make, model, and serial number",
      "Routing to R2-certified downstream processors",
      "Scheduling for most Omaha pickups",
    ],
    processHeading: "How Omaha Computer Recycling Works",
    process: [
      {
        step: "01",
        title: "Submit Your Request",
        desc: "Complete our pickup form or call 402-243-6922. We confirm your Omaha pickup promptly and coordinate scheduling around your timing.",
      },
      {
        step: "02",
        title: "Pickup at Your Location",
        desc: "Our team arrives with intake sheets. Every computer, laptop, and workstation is logged by make, model, and serial number before we depart your facility.",
      },
      {
        step: "03",
        title: "Processing and Downstream Routing",
        desc: "Equipment is transported to our Lincoln facility for NIST-compliant data destruction; applicable recovered material is then routed to R2-certified downstream processors.",
      },
      {
        step: "04",
        title: "Documentation Delivered",
        desc: "Your Certificate of Destruction and asset manifest are delivered digitally promptly after processing.",
      },
    ],
    benefitsHeading: "Why Omaha Organizations Use Precision E-Cycle",
    benefits: [
      {
        title: "No Local Facility Needed",
        desc: "You do not need to transport equipment to a facility. We come to your Omaha location, handle all intake, and transport everything to our Lincoln processing plant.",
      },
      {
        title: "Healthcare and Financial Compliance Ready",
        desc: "Omaha's UNMC, CHI Health, First National Bank, and other major employers require HIPAA and SOX-compliant disposal documentation. Our COD satisfies both.",
      },
      {
        title: "No Minimum Volume Requirement to Quote",
        desc: "Whether you have 10 computers or 1,000, contact us and we will confirm whether your volume qualifies for free pickup or advise on per-unit fees for smaller loads.",
      },
    ],
    faqHeading: "Computer Recycling in Omaha: Common Questions",
    faqs: [
      {
        question: "Do you offer free computer pickup in Omaha, NE?",
        answer:
          "Yes. We provide free bulk computer recycling pickup for organizations in Omaha and the surrounding Douglas and Sarpy County area for qualifying volumes, typically a business-scale load or a comparable mixed load.",
      },
      {
        question: "How quickly can you schedule a computer recycling pickup in Omaha?",
        answer:
          "Most Omaha pickups are confirmed promptly and scheduled promptly after the request. For larger decommissions requiring crew coordination, we provide a scheduling plan within one to two business days.",
      },
      {
        question: "Is data destruction included with Omaha computer recycling?",
        answer:
          "Yes. NIST 800-88 data destruction is included for all data-bearing devices at no additional charge for qualifying pickups. A serialized Certificate of Destruction is issued for every device and delivered digitally promptly.",
      },
      {
        question: "Can you recycle monitors and peripherals along with computers in Omaha?",
        answer:
          "Yes. We accept monitors, keyboards, mice, docking stations, printers, and other peripherals alongside computers. Monitors and some specialty items may incur a recycling fee, contact us for a complete quote.",
      },
    ],
    relatedServices: [
      { label: "Omaha Electronics Recycling", href: "/locations/omaha" },
      { label: "Server Disposal Omaha", href: "/locations/omaha/server-disposal" },
      { label: "Data Destruction Omaha", href: "/locations/omaha/data-destruction" },
      { label: "Computer Recycling Services", href: "/services/computer-recycling" },
    ],
    serviceName: "Computer Recycling, Omaha, NE",
    serviceSchemaDescription:
      "Free bulk computer and laptop recycling pickup for Omaha-area businesses. NIST 800-88 data destruction and Certificate of Destruction included.",
    expandedSections: [
      {
        heading: "Compliance Framework for Computer and Laptop Disposal",
        paragraphs: [
          "Computer recycling at the business level sits at the intersection of two regulatory regimes. The first is data sanitization. Every laptop, desktop, and workstation contains at least one storage device, and most contain several once you count NVMe drives, eMMC chips on the board, removable drives, and BIOS-level firmware storage. NIST Special Publication 800-88 Revision 1 is the federal standard for media sanitization and defines three method tiers: Clear (logical overwrite), Purge (cryptographic erasure or block-level overwrite verified to be unrecoverable), and Destroy (physical destruction such as shredding). Every device that passes through Precision E-Cycle is sanitized at the Purge or Destroy level depending on media type, and the method applied is recorded on the serialized Certificate of Destruction issued for that asset.",
          "The second regime is downstream environmental compliance. The R2 (Responsible Recycling) standard, currently at version R2v3, requires certified recyclers to track all materials through to final disposition and to use only audited downstream vendors. Precision E-Cycle does not hold R2 facility certification, but routes all downstream material exclusively through R2-certified processors and smelters who meet these requirements and undergo independent third-party auditing. For computer recycling that means working batteries are removed and routed to certified battery processors, circuit boards go to certified smelters that recover precious metals through closed-loop processes, and plastics are processed without export to non-OECD countries. Every Precision E-Cycle engagement produces an asset manifest that ties each serial number to its destruction method and a downstream summary that documents where component streams ultimately landed. This is the documentation regulators, auditors, and insurance carriers ask for when they ask to see proof.",
          "For organizations subject to industry-specific frameworks (HIPAA for covered entities and business associates, GLBA and FACTA for financial services, FERPA for educational institutions, SOX for public companies, FISMA for federal contractors), the same documentation supports those audits. The COD format is designed to satisfy the most stringent of these without the client having to translate between standards.",
        ],
      },
      {
        heading: "Computer Recycling for Omaha Enterprises",
        paragraphs: [
          "The Omaha metro carries a denser concentration of national headquarters and Fortune-class organizations than any other market in our 500-mile service radius. Mutual of Omaha, Union Pacific, Berkshire Hathaway, First National Bank, and the cluster of insurance and financial services firms in the metro all manage large workstation and laptop fleets with formal asset management programs. Precision E-Cycle coordinates pickups from corporate campuses across Omaha and the surrounding metro, including the Aksarben, Old Market, Regency, Boys Town, and Westroads corridors, along with the Carter Lake and Council Bluffs side of the river.",
          "For organizations operating out of multi-building campuses, we schedule consolidated pickups that move equipment from staging areas to our Lincoln processing facility in a single coordinated load. This minimizes disruption to facilities operations and gives the IT and procurement teams a single point of contact and a single documentation package for the full retirement event.",
        ],
      },
      {
        heading: "What to Expect on Pickup Day in Omaha",
        paragraphs: [
          "An Omaha pickup runs on a coordinated schedule that accounts for the drive between our Lincoln processing facility and the client site. For corporate campus pickups we typically arrive in a window agreed during scheduling, complete the on-site scan-in against the manifest, load through the dock or the loading area designated by facilities, and close out the chain-of-custody log before departing. For multi-building campuses, a single pickup can consolidate equipment from multiple staging areas in one trip when the buildings are within a reasonable on-site loop.",
          "Equipment arrives at our processing facility shortly after the pickup window. Intake processing begins on arrival, and the per-drive Certificates of Destruction are typically delivered promptly after processing. The full documentation package, including the asset manifest, chain-of-custody log, and downstream summary, follows as a single consolidated deliverable rather than in piecemeal updates.",
          "For Omaha campus pickups that span multiple buildings, multiple departments, or multiple decision-makers, we work directly with whichever combination of stakeholders the organization prefers and consolidate the documentation back to a single record at the level of granularity the organization specifies during scoping.",
        ],
      },
    ],
  },

  // ────────────────────────────────────────────────────────────────────────────
  // OMAHA, SERVER DISPOSAL
  // ────────────────────────────────────────────────────────────────────────────
  "omaha/server-disposal": {
    city: "Omaha",
    state: "NE",
    citySlug: "omaha",
    serviceSlug: "server-disposal",
    heroBadge: "Omaha, NE",
    heroH1: "Server Disposal Omaha, NE",
    heroSubheadline:
      "Enterprise server decommissioning and certified disposal for Omaha-area data centers and IT teams. Full chain-of-custody and NIST-compliant data destruction included.",
    heroImage: "/images/server-disposal-hero.png",
    introHeading: "Server Decommissioning and Disposal for Omaha Enterprises",
    introP1:
      "Precision E-Cycle handles server disposal and data center decommissions for organizations throughout the Omaha metropolitan area. Omaha's growing technology and financial services sector means IT teams are regularly managing end-of-life server hardware that requires compliant, documented disposition. We provide a complete service from on-site inventory to final Certificate of Destruction.",
    introP2:
      "Whether you are decommissioning a single server closet or a multi-rack data center, our team arrives at your Omaha facility with intake documentation, secures your equipment under full chain of custody, and transports it to our Lincoln processing facility for NIST 800-88 compliant data destruction and verified downstream recycling.",
    includes: [
      "Free pickup for qualifying server volumes",
      "On-site serial-level inventory at your location",
      "NIST 800-88 data destruction on all storage",
      "Certificate of Destruction per data-bearing device",
      "Full chain-of-custody from intake to certification",
      "Applicable routing to R2-certified downstream processors",
    ],
    processHeading: "Omaha Server Disposal Process",
    process: [
      {
        step: "01",
        title: "Request a Decommission Quote",
        desc: "Describe your server count, hardware types, and any access or scheduling requirements. We respond with a plan and timeline promptly.",
      },
      {
        step: "02",
        title: "On-Site Inventory at Your Omaha Location",
        desc: "Our crew arrives with intake documentation and logs every server, drive, and networking device by make, model, and serial number before anything is moved.",
      },
      {
        step: "03",
        title: "Secured Transport to Our Facility",
        desc: "Equipment is transported to our Lincoln processing facility in a secured vehicle with full chain-of-custody documentation maintained throughout.",
      },
      {
        step: "04",
        title: "Destruction and COD Delivery",
        desc: "All storage media is destroyed per NIST 800-88. A serialized COD for every data-bearing device is delivered digitally promptly.",
      },
    ],
    benefitsHeading: "Why Omaha IT Teams Choose Precision E-Cycle for Server Disposal",
    benefits: [
      {
        title: "Coordinated Logistics for Large Decommissions",
        desc: "We plan multi-phase decommissions around your data center access windows, maintenance schedules, and project timelines, no surprise delays.",
      },
      {
        title: "Audit-Ready Documentation",
        desc: "Every Omaha server disposal engagement produces documentation that holds up under HIPAA, SOX, GLBA, and PCI DSS audit scrutiny.",
      },
      {
        title: "R2-Certified Downstream Processors",
        desc: "Applicable material may be routed to R2-certified downstream processors, with available downstream vendor records for covered server processing.",
      },
    ],
    faqHeading: "Server Disposal in Omaha: Common Questions",
    faqs: [
      {
        question: "Do you pick up servers from Omaha businesses and data centers?",
        answer:
          "Yes. We provide server pickup and full data center decommission services throughout Omaha and the surrounding metro area. We can accommodate on-site access during and after business hours for large decommissions.",
      },
      {
        question: "What server hardware do you accept from Omaha organizations?",
        answer:
          "We accept all major server types including rack-mount, blade, and tower servers, as well as associated data center hardware such as network switches, SAN arrays, UPS units, and structured cabling. We process Dell, HP, IBM, Cisco, Lenovo, and SuperMicro equipment.",
      },
      {
        question: "How long does a server decommission take in Omaha?",
        answer:
          "Single-room decommissions are typically completed in one visit. Larger multi-rack or multi-room projects are scoped during your initial consultation and scheduled across the number of visits required. We provide a written timeline before work begins.",
      },
      {
        question: "What compliance documentation do I receive for Omaha server disposal?",
        answer:
          "You receive a serial-level asset manifest covering all hardware removed, and a Certificate of Destruction for every data-bearing device listing the serial number, destruction method, and date. Documentation is delivered digitally promptly and is suitable for HIPAA, SOX, GLBA, and PCI DSS compliance programs.",
      },
    ],
    relatedServices: [
      { label: "Omaha Electronics Recycling", href: "/locations/omaha" },
      { label: "Computer Recycling Omaha", href: "/locations/omaha/computer-recycling" },
      { label: "Data Destruction Omaha", href: "/locations/omaha/data-destruction" },
      { label: "Server Disposal Services", href: "/services/server-disposal" },
    ],
    serviceName: "Server Disposal, Omaha, NE",
    serviceSchemaDescription:
      "Enterprise server decommissioning and certified disposal for Omaha-area organizations. Full chain-of-custody and NIST 800-88 data destruction included.",
    expandedSections: [
      {
        heading: "Compliance Framework for Server and Data Center Decommission",
        paragraphs: [
          "Server disposal differs from desktop and laptop recycling in three ways: scale, complexity, and the concentration of sensitive data on each chassis. A single 2U server can hold a dozen or more drives in a RAID configuration, and a half-populated rack can carry more storage than an entire department of laptops. NIST 800-88 Rev. 1 applies to every one of those drives, and our chain-of-custody documentation captures each drive at the serial level rather than at the chassis level. RAID striping does not reduce the obligation. Each constituent drive is sanitized using the method appropriate to its media type, and the Certificate of Destruction lists each drive separately even when they shipped together in one host.",
          "Data center decommissions add a logistics layer on top of the destruction obligation. Cabinets need to be powered down in a controlled sequence, network and power cables traced and removed, rails released, and units palletized for transport without dropping or damaging media. Precision E-Cycle coordinates these projects with the on-site IT or facilities team, schedules pickups around production windows, and provides asset-level scan-in receipts the moment equipment leaves the building. For colocation tenants who do not own the cage, we coordinate directly with the data center operator on access, escort, and load-out documentation so the tenant satisfies their lease exit requirements.",
          "Witnessed destruction is available on-site for clients whose policies prohibit data-bearing media from leaving their premises in any state other than physically destroyed. In that workflow, our technician brings shredding equipment to the facility, performs destruction in front of a designated client representative, and issues the COD on the spot before equipment leaves with us as scrap. This pattern is common for clients managing classified workloads, financial trading systems, and certain healthcare deployments.",
        ],
      },
      {
        heading: "Server Disposal and Data Center Decommission in Omaha",
        paragraphs: [
          "Omaha is home to substantial data center activity, including major colocation operators, financial services trading and back-office infrastructure, healthcare systems serving the UNMC corridor, and the regional infrastructure for the national companies headquartered in the metro. Decommission projects in this market range from single-rack refreshes to multi-cabinet retirements over several weeks. Precision E-Cycle scopes each engagement around the actual rack count, drive count, and access constraints rather than forcing a one-size-fits-all timeline.",
          "For colocation tenants we coordinate directly with the data center operator on cage access, escort scheduling, freight elevator reservations, and load-out documentation. The tenant ends the engagement with one consolidated package: an asset-level inventory, drive-level Certificates of Destruction, downstream processing summary, and any operator-specific cage clearance forms that the data center requires for the lease exit. For owner-operated rooms we work directly with internal facilities and IT teams on the same documentation set.",
        ],
      },
      {
        heading: "Omaha Data Center and Server Room Decommission Logistics",
        paragraphs: [
          "Omaha server engagements range from single-rack pickups to coordinated decommissions across multiple cabinets and multiple sites. For colocation tenants we handle the operator-side coordination directly, including cage access requests, escort scheduling, freight elevator reservations, and any operator-specific cage clearance or load-out documentation. For owner-operated server rooms we coordinate with internal IT and facilities teams on power-down sequencing, on-site work windows, and any building access requirements specific to the location.",
          "For larger engagements we assign a dedicated project contact who carries the engagement from initial scoping through documentation delivery. This keeps internal IT and procurement teams from having to re-explain the scope at every step, and it keeps the documentation deliverables on a defined schedule rather than as an open-ended catch-all.",
          "For Omaha colocation tenants approaching a contract end-date, a facility migration, or a hardware refresh tied to a vendor warranty cycle, we coordinate the decommission timeline directly with the operator and deliver documentation aligned to the tenant's internal compliance and procurement schedule.",
          "For Omaha engagements that require coordination with a building landlord, a property manager, or a colocation operator, that coordination is handled directly so the client team is not stuck relaying scheduling messages between multiple parties on the morning of the work.",
        ],
      },
    ],
  },

  // ────────────────────────────────────────────────────────────────────────────
  // OMAHA, DATA DESTRUCTION
  // ────────────────────────────────────────────────────────────────────────────
  "omaha/data-destruction": {
    city: "Omaha",
    state: "NE",
    citySlug: "omaha",
    serviceSlug: "data-destruction",
    heroBadge: "Omaha, NE",
    heroH1: "Data Destruction Omaha, NE",
    heroSubheadline:
      "NIST 800-88 compliant data destruction and hard drive destruction for Omaha-area businesses. Certificate of Destruction issued for every device.",
    heroImage: "/images/data-destruction-hero.png",
    introHeading: "Certified Data Destruction Pickup for Omaha Organizations",
    introP1:
      "Precision E-Cycle provides NIST SP 800-88 Rev. 1 compliant data destruction for organizations throughout the Omaha metropolitan area. We collect your drives, servers, and data-bearing devices and transport them to our Lincoln processing facility for documented destruction. A Certificate of Destruction identifying every device by serial number is delivered promptly.",
    introP2:
      "Omaha's healthcare, financial services, and government sectors are among the most compliance-intensive in Nebraska. UNMC, Methodist Health, First National Bank of Omaha, and dozens of financial institutions require HIPAA and SOX-compliant data destruction documentation. Our process is purpose-built to produce that documentation efficiently and reliably.",
    includes: [
      "NIST SP 800-88 Rev. 1 compliant destruction",
      "Free pickup for qualifying volumes in Omaha",
      "Serialized Certificate of Destruction per device",
      "Software wipe, degaussing, or physical shredding",
      "Covers HDD, SSD, NVMe, tape, and mobile storage",
      "Chain-of-custody maintained from pickup to COD",
    ],
    processHeading: "Omaha Data Destruction Process",
    process: [
      {
        step: "01",
        title: "Schedule Your Omaha Pickup",
        desc: "Contact us with your drive count and location. We confirm your Omaha pickup promptly and typically schedule promptly.",
      },
      {
        step: "02",
        title: "Secure Pickup and Chain-of-Custody",
        desc: "We collect your drives and data-bearing devices, log each one by serial number and model, and provide you with an intake receipt before departing.",
      },
      {
        step: "03",
        title: "NIST-Compliant Destruction",
        desc: "At our Lincoln facility, each drive is destroyed using the NIST 800-88 method appropriate for its media type, overwrite, degaussing, or physical shredding.",
      },
      {
        step: "04",
        title: "COD Delivered Promptly",
        desc: "A serialized Certificate of Destruction is issued for every device and delivered digitally promptly after processing.",
      },
    ],
    benefitsHeading: "Why Omaha Organizations Trust Our Data Destruction",
    benefits: [
      {
        title: "HIPAA and SOX Ready Documentation",
        desc: "Our Certificate of Destruction identifies each device by serial number and destruction method, satisfying HIPAA 45 CFR 164.310(d) and SOX data retention requirements.",
      },
      {
        title: "All Media Types Covered",
        desc: "We destroy hard disk drives, solid-state drives, NVMe drives, magnetic tape, mobile devices, and USB storage, every type of media under one COD.",
      },
      {
        title: "Pickup Comes to You",
        desc: "You do not need to transport sensitive media across Omaha. We come to your location, maintain chain of custody from the moment of pickup, and handle everything from there.",
      },
    ],
    faqHeading: "Data Destruction in Omaha: Common Questions",
    faqs: [
      {
        question: "Do you provide data destruction pickup service in Omaha, NE?",
        answer:
          "Yes. We pick up hard drives, servers, and other data-bearing devices from businesses throughout Omaha and the surrounding metro area. Most Omaha pickups are scheduled promptly after your request.",
      },
      {
        question: "What destruction methods do you use for Omaha data destruction?",
        answer:
          "We use NIST 800-88 compliant methods matched to the media type: software overwrite for drives eligible for verified reuse, degaussing for magnetic hard drives, and physical shredding for drives at end of life or where Destroy-level sanitization is required.",
      },
      {
        question: "Does your data destruction service satisfy HIPAA requirements for Omaha healthcare organizations?",
        answer:
          "Yes. Our Certificate of Destruction documents the destruction method and identifies each device by serial number, satisfying the media disposal requirements under HIPAA 45 CFR 164.310(d)(2)(i). We also support Business Associate Agreement requests from covered entities.",
      },
      {
        question: "How quickly can I get data destruction service in Omaha?",
        answer:
          "Most Omaha requests are confirmed promptly and scheduled promptly. For urgent compliance timelines, call us at 402-243-6922 and we will do our best to accommodate expedited scheduling.",
      },
      {
        question: "Does degaussing work on solid-state drives?",
        answer:
          "No, and treating it as a universal method is a costly mistake. Degaussing disrupts a magnetic field, which is why it works on spinning drives and backup tape. Solid-state media stores data in NAND flash cells with no magnetic component, so a degausser passes over an SSD with no effect at all. An organization that degausses a mixed load and files the certificate has destroyed some of its data and none of the rest, while holding paperwork that says otherwise.",
      },
      {
        question: "Our drives are encrypted. Do we still need destruction?",
        answer:
          "Cryptographic erase is a recognized Purge method under NIST 800-88, but it only holds if encryption covered the whole volume and you can prove the key was destroyed. Most organizations cannot produce that evidence during an audit months later. Encryption is a strong control while a device is in service. It is not a substitute for a documented sanitization event when the device leaves your control, and regulators treat the two differently.",
      },
      {
        question: "Can Omaha healthcare and financial clients witness destruction?",
        answer:
          "Yes. Witnessed sessions are common for Douglas and Sarpy County clients whose internal controls require direct observation rather than documentary evidence alone. This comes up most with health systems, banks and credit unions, and organizations supporting federal work in the metro. Sessions can be arranged at our processing facility or coordinated at your site. Tell us the volume and media types involved and we will scope how the session runs and what you receive afterward.",
      },
    ],
    relatedServices: [
      { label: "Omaha Electronics Recycling", href: "/locations/omaha" },
      { label: "Computer Recycling Omaha", href: "/locations/omaha/computer-recycling" },
      { label: "Server Disposal Omaha", href: "/locations/omaha/server-disposal" },
      { label: "Data Destruction Services", href: "/services/data-destruction" },
    ],
    serviceName: "Data Destruction, Omaha, NE",
    serviceSchemaDescription:
       "NIST 800-88-informed data-processing options for Omaha-area organizations. Pickup service with applicable processing documentation based on confirmed scope.",
    expandedSections: [
      {
        heading: "Compliance Framework for Certified Data Destruction",
        paragraphs: [
           "Data destruction as a standalone service (separate from full equipment recycling) can fit when an organization is keeping the chassis but retiring the storage, when drives have been pulled from systems for replacement, or when a compliance event generates a stack of media that needs documented end-of-life handling. Precision E-Cycle can support these patterns under a NIST 800-88 Rev. 1-informed process. The standard recognizes three sanitization categories, and the applicable method is selected based on media type, sensitivity, reuse plans, and confirmed requirements.",
           "Where the service scope includes it, method selection can be documented per drive on a Certificate of Destruction. The record may capture make, model, serial number, capacity, media type, method, operator, date, and a reference to the chain-of-custody log. Organizations should confirm with counsel and their compliance teams whether the resulting documentation meets their HIPAA, SOX, GLBA, FACTA, FERPA, FISMA, or contractual requirements.",
          "On-site witnessed destruction is available when contractual or regulatory requirements demand that media never leave the premises intact. For routine pickups, drives are transported in tamper-evident containers with locked seals and tracked from pickup through destruction with no unaccounted intermediate handling.",
        ],
      },
      {
        heading: "Data Destruction Services for Omaha Organizations",
        paragraphs: [
           "Omaha-based financial services firms, insurance carriers, healthcare systems anchored by UNMC and Methodist, and corporate IT teams supporting large headquarters may need documented data destruction. This work can run on a recurring basis tied to internal refresh cycles, with project-based engagements for litigation holds, tenant moves, M&A integration cleanup, or post-incident remediation. Intake and documentation are scoped to the workflow and records the organization needs.",
           "On-site witnessed destruction may be available across the Omaha metro when contractual or regulatory requirements call for media to remain intact only until witnessed processing. Our technician can travel to the site, perform agreed destruction with industrial shredding equipment in front of a designated witness, and provide applicable records. For routine pickups, drives may travel in tamper-evident containers with locked seals and a chain-of-custody log that closes out at our processing facility in Lincoln.",
        ],
      },
      {
        heading: "Drive Pickup and On-Site Options Across the Omaha Metro",
        paragraphs: [
           "Drive-only pickups in the Omaha metro can be scheduled alongside full-equipment pickups. We may supply tamper-evident transport containers in advance for clients who prefer to seal at their own site, or load and seal on-site through our technician. The agreed pattern determines the chain-of-custody record and any per-drive documentation, including make, model, serial number, capacity, media type, method, date, and operator where applicable.",
           "On-site witnessed destruction may be available across the Omaha metro for organizations whose contractual or regulatory frameworks require media to leave the premises only after physical destruction. Our technician can travel to the site with industrial shredding equipment, perform destruction in front of a designated client representative, and provide applicable records. This is one option for financial services, insurance, healthcare, and certain government engagements.",
          "For Omaha organizations operating under defined retention policies that require periodic media destruction, we offer a recurring pickup arrangement that uses the same chain-of-custody and Certificate of Destruction format as one-off engagements, removing the overhead of re-scoping every individual destruction cycle.",
        ],
      },
      {
        heading: "Who Retires Data-Bearing Media Across the Omaha Metro",
        paragraphs: [
          "Omaha concentrates organizations whose disposal obligations are not interchangeable, and the right method follows the obligation rather than the org chart. Nebraska Medicine at UNMC, CHI Health Creighton University Medical Center, and Methodist Health System retire clinical workstations, imaging peripherals, and mobile devices holding protected health information under HIPAA 45 CFR 164.310(d), where the evidence has to survive a review naming one specific device.",
          "The financial sector applies a different test. Mutual of Omaha, First National Bank, and the banks, credit unions, and wealth managers across the metro operate under the Gramm-Leach-Bliley Safeguards Rule and the FACTA Disposal Rule, where the question is whether consumer financial data was rendered unreadable and whether the record proves it. Union Pacific and Berkshire Hathaway retire corporate fleets on asset-management schedules rather than in single events.",
          "Federal and education work rounds it out. Organizations supporting Offutt Air Force Base carry controlled-data handling expectations that make method documentation non-negotiable, while the University of Nebraska Omaha, Creighton University, and Metropolitan Community College carry FERPA obligations under 20 U.S.C. 1232g across fleets that move on academic calendars. We scope the method against what the media held, not the category of organization retiring it.",
        ],
      },
    ],
  },
};
