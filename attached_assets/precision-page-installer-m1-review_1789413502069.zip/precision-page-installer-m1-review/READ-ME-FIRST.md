# Precision page installer milestone 1 review package

This package contains a proposed fix for the deterministic `CityServiceData` finishing path. It is a review package, not a complete repository and not a patch that should be copied blindly over a working branch.

## Source revisions

- Primary source: `xkluziv12/precision-ecycle-platform`, branch `claude/content-blocks`, revision `85a911560`.
- Hub-writer reference: branch `claude/st-louis-planning-page`, revision `83c37f9`.
- The reported eleven-commit local merge was not available on GitHub when this package was created.

Because the target merged branch may contain newer or conflicting work, review every file against the actual merged revision before applying anything.

## Unzip

```bash
mkdir precision-page-installer-m1-review
unzip precision-page-installer-m1-review.zip -d precision-page-installer-m1-review
cd precision-page-installer-m1-review
```

The `repo-files/` directory preserves the intended paths inside the Precision repository.

## Review rules

1. Start from the merged Precision branch in a new branch or isolated Git worktree. Never use `main`.
2. Keep the original branch unchanged until the review and tests pass.
3. Do not replace entire existing files automatically. Compare and port the relevant changes with a three-way diff.
4. Pay special attention to `scripts/package.json`, `CityServicePage.tsx`, `schema.ts`, and `review-overlay.ts`, because newer merged work may exist in those files.
5. Preserve the existing hub writer. The new command is deliberately named `write-city-service-page.ts` to avoid colliding with `write-city-page.ts` on the merged branch.
6. Do not edit `ratified-markets.ts`, weaken gates, authorize a service, make a paid model call, publish, deploy, or merge to `main`.
7. Treat generated content, market status, service authorization, and schema eligibility as separate contracts.

## What to inspect

- `repo-files/scripts/src/page-installer/city-service.ts`: nested validation, admission checks, idempotent insertion, and rollback.
- `repo-files/scripts/src/page-installer/city-service.test.ts`: five no-model tests.
- `repo-files/scripts/src/write-city-service-page.ts`: CLI entry point.
- `repo-files/scripts/package.json`: two added script entries only. Merge those entries; do not replace a newer package file.
- `repo-files/artifacts/precision-ecycle/src/pages/_cityServiceData.ts`: optional metadata and code-owned posture fields.
- `repo-files/artifacts/precision-ecycle/src/pages/CityServicePage.tsx`: planning-market project-review behavior.
- `repo-files/scripts/src/factory/pipeline/schema.ts`: service-spoke schema support.
- `repo-files/scripts/src/factory/pipeline/review-overlay.ts`: service-spoke staging and code-owned posture derivation.
- `repo-files/docs/PAGE-INSTALLER-MILESTONE-1-REVIEW.md`: evidence and remaining runtime proof.

## Drift checklist

For every existing target file, classify the proposed change as:

- `APPLIES CLEANLY`
- `ALREADY IMPLEMENTED`
- `CONFLICTS WITH NEWER WORK`
- `INCORRECT FOR CURRENT CONTRACT`
- `REQUIRES BUSINESS DECISION`

Confirm these contracts from the merged code rather than from old handoffs:

- Hub FAQ count is 8; method and service spoke FAQ count is 5.
- Factory service spokes use `CityServiceData` with 6 includes, 4 process steps, 3 benefits, 5 FAQs, 6 related links, and 3 expanded sections.
- Planning posture comes from the ratified market status, not model output.
- `LocalBusiness` eligibility remains separate from service availability posture.
- A service-spoke install requires the service slug to be explicitly authorized for that market.
- Final gates are the recipe gates plus global publish gates.

## Tests to run after careful application

```bash
pnpm --filter @workspace/scripts run write-city-page-test
pnpm --filter @workspace/precision-ecycle run typecheck
```

Then, in an isolated worktree with the real Replit assets available:

1. Install a synthetic test record using the programmatic test-only option.
2. Build the real site.
3. Assert that the exact new prerendered route exists.
4. Assert that the rendered HTML contains `INSTALL-SENTINEL-7f3a` and the fixture H1.
5. Run route-scoped SEO and schema gates.
6. Confirm planning posture has no pickup CTA and no city-scoped `LocalBusiness` node.
7. Discard the worktree after capturing the results.

The production CLI intentionally provides no market-authorization bypass.

## Expected reviewer response

Return:

1. The target branch and commit reviewed.
2. The drift classification for every file.
3. Exact test commands and results.
4. Any line-level defect or regression found.
5. Whether the synthetic rendered route passed.
6. Whether any requested change requires Mark's business approval.
7. A clear recommendation: accept, revise, or reject.
