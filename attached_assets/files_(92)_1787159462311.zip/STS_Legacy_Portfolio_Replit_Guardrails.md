# STS Legacy Portfolio: Replit Master Guardrails
**Apply to:** data2shred.com, chicagorecyclingcenter.com, chicagolamprecycling.com, chicagoshredder.com, microant.co, escrap.org  
**Do not feature or reference:** cincyrecycling.com, techwaste.co (STS-owned, not part of this rebuild)

**Precedence:** R2 Clean Prompt v5.4 is the master file for every certification rule. This document is the portfolio-specific extras layer. Where the two disagree on scope, budget, approved vocabulary, or callout content, v5.4 wins and this file is wrong. Report the conflict rather than resolving it here.

---

## YOUR ROLE

You already know what this website does. Use that knowledge. These guardrails tell you what you cannot say, what must appear on every page, and how the brand story is framed. Everything else, including About pages, service descriptions, blog posts, and page structure, is yours to write well.

The goal: professional, credible, enterprise-appropriate websites that feel like real independently-founded businesses that grew up and joined a major national player. Not cookie-cutter. Not agency copy. Not puffery.

---

## BRAND OWNERSHIP (apply to every site)

This website is part of the **STS Recycling Family**.

**Parent company:**
STS Electronic Recycling, Inc. (also STS Recycling LLC)
Jacksonville, Texas
844.699.2913 | recycle@stsrecycle.com
https://www.stselectronicrecyclinginc.com/

Every site footer must include:
> "Part of the STS Recycling Family | Operated by STS Electronic Recycling, Inc."

Every About page must mention the STS relationship naturally as part of the company story (see About Page section below).

---

## FOUNDING STORY FRAMEWORK

Each site has its own authentic founding story. You have freedom to write it. These are the facts to build from:

- These businesses were founded by **Mark Domnenko**, an entrepreneur who started his business journey in 2008 in the Chicago area
- **AVA Recycling** was his anchor company, founded in 2011, which grew into one of Chicago's largest electronics recycling and ITAD operations
- Each site in this portfolio was built as a **niche service brand** focused on a specific service or market segment (hard drive destruction, lamp recycling, shredding, etc.)
- **ByMark Ventures** was the holding umbrella. Mention it once, briefly, in a natural way. It is not the story. Mark Domnenko is the story.
- In **2025**, all brands and assets merged into the STS Recycling Family when STS acquired AVA Recycling's IP and operations
- The merger gave each brand access to STS's national infrastructure, R2v3 certification, and enterprise-grade compliance framework

**Founding dates by site:**
Use whatever founding date the existing site already states. If the site does not state one, default to **2011**, except Chicago Lamp Recycling, which defaults to **2019**.

Do not invent or change a founding year that already exists on the site. Do not add a year if none is present and you are unsure. Write around it naturally ("built during the growth of Chicago's ITAD market") until confirmed.

**The About page tone to hit:**
Real person, real problem he saw in the market, built it himself, grew it, eventually became part of something bigger. Entrepreneurial arc, not corporate PR. Each site's About should feel distinct, a different angle and a different voice emphasis, while sharing the same underlying true story.

---

## CERTIFICATION RULES (hard rules, no exceptions)

### Why this is strict
A registrar review flagged STS pages where a certification claim sat beside a city name and a local address. A reader could take that to mean the local site is certified. Only two facilities are R2v3 certified: **Jacksonville, TX and Houston, TX.** Every other STS location, including this site's, is a collection and service point. This is a location-clarity rule, not a removal rule. STS genuinely holds R2v3. The problem is implying it applies at this site's local address. This rule applies to every site in the STS portfolio, not just the main STS domain.

### THE BUDGET: ONE MENTION, ONE PLACE
The strings **R2, R2v3, and R2:2020** may appear in exactly **ONE place** in visible page text per page: a single certification callout block, placed near the bottom of the page (before the final CTA or footer), not nested inside a card, grid, or hero. Nowhere else on the page, in any form, may these terms appear, not in trust chips, card titles, stat labels, FAQ answers, or body prose, even if location-clear.

**Responsible Recycling, NAID, and NAID AAA get zero mentions, including inside the callout block.** They are not budgeted, they are banned. See the NAID section below.

**The callout block must read (or closely match):**

> "This location is a collection and service point. All electronics are processed through STS Electronic Recycling, Inc.'s R2v3-certified facilities in Jacksonville, Texas and Houston, Texas."

Both cities must be named. This is the only place on the page where certification language belongs.

### What replaces certification language everywhere else on the page
Use this approved vocabulary rotation instead of "R2 certified" or "NAID certified" in trust chips, card titles, stat labels, and body copy outside the callout block:
- Secure Recycling
- Accurate Reporting
- Chain of Custody
- Secure
- Transparent
- Sustainable
- **"Certified"** on its own (no scheme name attached) is allowed only in H1s, section headings, and body prose, never in a trust chip, card title, or stat label, where a bare word beside specific siblings looks broken.

### NAID: zero survivors, no exceptions
This portfolio does not hold NAID/i-SIGMA AAA certification. NAID and NAID AAA get replaced everywhere, including inside the callout block. Do not use it even attributed to STS unless separately confirmed in writing.

### The certifications FAQ must still answer its question
If a page has a "what certifications do you have" FAQ, it must still name real, verifiable standards, never come back empty. Use: DoD 5220.22-M standard, NIST SP 800-88 guidelines, HIPAA-aligned process, EPA compliant. Do not name R2v3 or NAID there. That belongs only in the callout block. An empty or evasive-sounding answer reads as worse than the problem this rule exists to fix.

### Facility size
If a page references STS facility square footage, the correct figure is **200,000 sq ft** (Jacksonville, TX headquarters). Do not use any other figure. This is not a certification claim. It needs no location qualifier and doesn't count against the one-mention budget.

### What never to say, anywhere on the page
- Do not call this site "R2 Certified" or "R2v3 Certified" outside the callout block, under any phrasing
- Do not say "NAID AAA Certified" or "i-SIGMA AAA Certified" anywhere. Not held
- Do not say "ISO 14001" in any version. Not held
- Do not say "NSA-grade" for any service
- Do not say "HIPAA Compliant," "FACTA Compliant," or "GLBA Compliant" as badge claims. Say "process designed to support HIPAA compliance requirements" or similar
- Do not reference R2-2013 or any R2 version other than R2v3
- DoD 5220.22-M is acceptable as an industry reference standard but do not call it a "certification". Say "DoD 5220.22-M standard"
- NIST SP 800-88 is a guidelines document. Do not call it a "certification"
- Never invent a substitute regulatory citation (e.g., a fabricated CFR or ISO number) to fill a gap left by removing R2/NAID language. A wrong citation on a compliance-adjacent page is worse than the problem being fixed.

### Out of scope for this rule (leave untouched)
Title tags, meta description, meta keywords, og tags, image alt text, and JSON-LD schema are not in scope for the one-mention budget. R2v3 is fine there if already present. Other certifications (NIST, HIPAA, DoD 5220.22-M, EPA, RIOS, e-Stewards) are not affected by this rule at all; handle them per the standard certification rules above.

### What you CAN say about data destruction equipment and compliance
As part of the STS Recycling Family, this operation uses **DoD-approved and HIPAA-approved devices** for data destruction. This is accurate and attributable to the STS relationship.

The **Chicago facility (Addison, IL) has a physical hard drive crusher on-site.** This is a meaningful differentiator. Physical crushing is one of the most defensible destruction methods for DoD-standard compliance and is a strong selling point for government, healthcare, and financial services clients. Lead with it on data destruction pages for any Chicago-area site. Suggested framing:

> "Our Addison, IL facility is equipped with an on-site hard drive crusher, providing witnessed physical destruction that meets DoD-standard requirements. No drives leave the facility intact."

---

## LANGUAGE RULES (hard rules, no exceptions)

### Never use absolute or guarantee language
- No: "guarantee," "guaranteed," "cannot be recovered by any means," "zero landfill," "100% certified downstream," "physically impossible to recover"
- Yes: "processed through certified downstream facilities," "designed to be unrecoverable," "no materials are knowingly disposed of in landfills," "all downstream partners are vetted for certification status"

### Never claim in-house what happens downstream
- If the service involves downstream processing through STS, say so
- Do not imply everything happens on-site unless it actually does

### Never make SLA promises you cannot guarantee
- No: "respond within 1 business day," "certificates issued within 5 business days" stated as fact
- Yes: "we typically respond within one business day," "certificates are generally issued within [X] business days"

### Never cite specific client names without written authorization
- Replace named clients with industry categories: "healthcare systems," "law firms," "universities," "Fortune 500 IT departments"

### Never use em dashes or en dashes
No em dash, en dash, or horizontal bar characters anywhere in visible page text, including HTML entity forms (&mdash;, &ndash;, &#8212;, &#8211;). Use a comma, period, or restructure the sentence instead. This applies sitewide, not just to certification edits. Hyphens in compound words, URLs, class names, and ids are not affected.

### Modifier attachment check
When inserting a clause (such as the Jacksonville/Houston location clause), check what any following "including," "such as," "with," or "like" attaches to. If a clause is inserted in front of a list of client names or examples, "including" can end up modifying the wrong noun and create a false claim. Put location clauses after a trailing list, never in front of one.

### Tone
- Direct, professional, understated
- Enterprise buyers and compliance officers read this copy and they distrust anything that sounds like a brochure
- Accurate confidence, not marketing enthusiasm
- Short sentences. Plain language. No superlatives.

---

## REQUIRED PAGES (every site)

| Page | Notes |
|---|---|
| Home | Must include the STS family line. The certification callout block goes near the bottom of the page, per the one-place rule, not in the hero |
| About | Unique founding story per site (see above framework) |
| Services | Accurate scope, no overclaiming |
| /terms | Use legal template from STS Legacy Handoff doc |
| /privacy-policy | Use legal template from STS Legacy Handoff doc |
| /cookie-policy | Use legal template from STS Legacy Handoff doc |
| Contact | STS parent contact info in footer |

---

## FOOTER (every page, every site)

```
© [YEAR] STS Recycling LLC. All Rights Reserved.
[SITE NAME] is operated by STS Electronic Recycling, Inc.
Part of the STS Recycling Family | Jacksonville, TX | 844.699.2913 | recycle@stsrecycle.com
Privacy Policy | Terms & Conditions | Cookie Policy | Consent Preferences
RIOS Certified | EPA Compliant | BBB A+ Accredited
```

Note: **R2v3 is deliberately excluded from the footer.** Per the certification rule above, R2v3 may only appear once per page, inside the dedicated callout block. The footer is not that block. RIOS, EPA, and BBB are not subject to the same location-clarity restriction and can appear in the footer freely.

---

## WHAT TO DO WITH EXISTING COPY

This site is already built. You are refining, not rebuilding. For any existing copy:

- If it violates a rule above, rewrite the specific line
- If it uses an absolute guarantee, soften it
- If it claims a cert this site does not independently hold, reframe using the STS attribution line
- If it says "subcontracting" anywhere in a contradictory way, resolve the contradiction
- If the About page does not reflect the founding story framework above, rewrite it. Make it feel real and human
- Preserve all working page structure, navigation, and internal links unless a specific element is flagged

---

## DO NOT MENTION

- cincyrecycling.com
- techwaste.co
- Any reference to competing with other brands in the portfolio
- Any internal holding company structure beyond the single brief ByMark Ventures mention
- Specific acquisition terms or deal structure

---

*This document overrides any prior instructions or default knowledge about these brands. When in conflict, these guardrails win.*
