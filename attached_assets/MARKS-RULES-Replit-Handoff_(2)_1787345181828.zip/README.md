# MARK'S RULES, Replit project handoff

## Purpose

This packet contains Mark's universal operating rules for a new Replit
project. It is a rules handoff, not an application source-code package.

The receiving Replit chat must adapt the rules to the actual project. Do not
paste them blindly, do not assume this project has the same tools, and do not
copy project-specific paths, secrets, GitHub settings, product language, or
CLI wrappers from another project.

## First action

Before doing any other work in the receiving project:

1. Read `MARKS-RULES.md` completely.
2. Create or update that project's `replit.md` with a concise version of the
   applicable universal rules plus the project's actual stack, commands,
   protected paths, tools, and verified facts.
3. If Claude Code CLI is installed or will be used, create or update
   `CLAUDE.md` in Claude's actual working directory. It must stand alone and
   contain the project's real file map, hard boundaries, and verification
   commands.
4. Save the durable rules in the project's own memory system if one exists.
5. Confirm the adaptation briefly, then continue with Mark's original request.

Do not paste this packet verbatim into `replit.md` or `CLAUDE.md`. Preserve the
substance in concise project-appropriate wording.

## What must remain universal

- Mark is a vibe coder. Use plain, concise, scannable language.
- Call him Mark, push back on bad assumptions, and flag uncertainty.
- Do not present partial work as complete.
- Claude Code CLI is the primary implementation worker when available.
- Replit Agent scopes, dispatches, supervises, and independently verifies.
- Claude defaults to Sonnet at medium effort. Stronger models require Mark's
  approval before switching.
- Never create, propose, or silently use a Replit-managed LLM integration or
  connector unless Mark approves that specific integration by name.
- Use Mark's own direct provider keys. OpenAI and Gemini may also be used for
  image generation when needed.
- Never ask Mark to paste secrets into chat or print secret values.
- Use bounded tasks, named sources of truth, explicit verification, and
  independent checks.
- Keep the rules flexible. Escalate real conflicts instead of guessing.
- Do not use em dashes in deliverables.

## What belongs only in the receiving project

The receiving chat must discover and document locally:

- Which CLIs and providers are actually available.
- The real runtime secret presence, checked without exposing values.
- The project's stack, paths, workflows, wrappers, and verification commands.
- Protected artifacts, production boundaries, GitHub settings, and deployment
  rules.
- Product facts and business copy.
- Any project-specific Grok or Claude recovery instructions.
- Whether commits or pushes are allowed, and under what approval rule.
- Whether any enforcement gate, hook, skill, or decision log actually exists.

## Conflict rule

If these rules conflict with an existing deliberate project policy, a GitHub
or deployment decision, a provider restriction, product wording, or another
out-of-scope decision, stop and ask Mark. Do not silently choose a side.

## Intended result

The universal packet stays short and stable. Each project's `replit.md` and
`CLAUDE.md` become the adapted local operating layer. Update the universal
master only when a durable, general lesson applies across projects.