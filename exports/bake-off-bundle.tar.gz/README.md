# Bake-Off bundle (STS Multi-LLM Pipeline Bake-Off)

A self-contained export of the multi-LLM bake-off: the **viewer app**, the
**harness** that runs each model through the No-GMB page-build pipeline, and the
shared **mc-core** library both depend on.

## What's inside

```
artifacts/bake-off/        Viewer app (Vite + React). Reads src/data/results.json
                           and public/screenshots/. This is what you see in the
                           preview pane — a leaderboard + per-model detail view.
scripts/src/bakeoff/       The harness (the thing that actually runs the bake-off):
  run.ts                   Entry point; resumable. `bakeoff` script.
  rescore-visual.ts        Re-score saved HTML without re-calling the models.
  engine.ts                Wraps the production AIEngine seam; appends the uniform
                           headless output contract to every model (apples-to-apples).
  providers.ts             Per-model adapters (Claude / Gemini / Grok / OpenAI).
  miniPrompts.ts           PORT of the No-GMB tool's copyPrompt() mini prompts.
  grounding.ts / gmb.ts    Shared research grounding + the two scenarios.
  score.ts / visual.ts     Scoring + visual judge.
  types.ts                 Harness types.
lib/mc-core/               Shared library: the REAL master prompts + checkers +
  src/prompts/             research stack the production engine uses. The bake-off
                           imports pageBuilderPrompt / seoAuditPrompt from here.
reference/no-gmb.html      The live No-GMB checklist tool — source of truth for the
                           mini prompts (see "Prompt sourcing" below).
```

## Prompt sourcing (important)

Nothing is read from git or the network at runtime. Both prompt sets are baked
into source:

- **Master prompts** (`pageBuilderPrompt`, `seoAuditPrompt`) live as inline
  string constants in `lib/mc-core/src/prompts/`. The harness imports them — they
  are the SAME source the production engine uses, not a copy.
- **Mini prompts** (`scripts/src/bakeoff/miniPrompts.ts`) are a hand-PORT of the
  No-GMB tool's `copyPrompt()` cases. They are a SNAPSHOT, not live-linked to
  `reference/no-gmb.html`. If the tool changes, re-sync this file by hand.

## Running it (in a pnpm workspace)

This is a pnpm-monorepo export. To run as-is you need a workspace that resolves
`@workspace/mc-core` (included here under `lib/`) and the scripts package.

- View results:   `pnpm --filter @workspace/bake-off run dev`
- Run a bake-off: `pnpm --filter @workspace/scripts run bakeoff`
- Re-score only:  `pnpm --filter @workspace/scripts run bakeoff:rescore`

Required keys for a live run (each model uses its own): ANTHROPIC_API_KEY,
GEMINI/GOOGLE key, XAI_API_KEY, OPENAI_API_KEY, plus PERPLEXITY_API_KEY +
SERPAPI_API_KEY for the shared research grounding. The viewer app needs no keys —
it just reads the captured results.json.

node_modules / dist / .tsbuildinfo were excluded — run `pnpm install`.
