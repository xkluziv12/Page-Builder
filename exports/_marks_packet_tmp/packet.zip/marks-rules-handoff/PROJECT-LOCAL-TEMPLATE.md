# Project-local adaptation template

Use this as a checklist for the receiving project. Replace every placeholder
with facts verified in that project. Do not copy AVA-specific facts from the
source packet.

## `replit.md`

Include:

- What the project does
- Stack and package/workflow commands
- Where the main frontend, API, database, and assets live
- Protected production or sibling artifacts
- Existing forms, auth, payments, or integrations that must not be replaced
- Which AI CLIs are installed and which route is active, API or CLI
- Runtime-verified secret names, never secret values
- Exact verification commands and known harmless warnings
- A pointer back to `MARKS-RULES.md`

## `CLAUDE.md`

Include:

- What Claude is working on
- The exact directory boundary for this artifact
- Hard rules and protected paths
- Content and design sources of truth
- Stack and concise file map
- Generalized recurring-bug lessons
- Exact typecheck, test, build, and screenshot commands
- The direct-provider rule and runtime secret-probe rule
- The local Git, deployment, and commit boundary

## Before continuing

Confirm that:

- The project-specific facts were discovered locally.
- No secret value was printed or copied.
- No GitHub, deployment, product-copy, or provider conflict was silently
  resolved.
- Inactive CLIs were left dormant.
- The local files contain the rules in their own concise wording.