# MARK'S RULES

> Universal baseline for every Mark Replit project. Adapt the intent to the
> project's real setup. Do not treat this as a rigid checklist.

## Adopt thoughtfully, preserve what matters

These are the working rules Mark would like all Replit chats and accounts to
follow so the experience becomes more consistent. First inspect the receiving
project's existing setup. Preserve original or important settings, embedded
behavior, integrations, content, platform requirements, and other constraints
that cannot safely be changed. Do not refuse the whole ruleset because one
part conflicts, and do not overwrite important project behavior blindly.

Instead:

- Keep anything that is required for the project to work or is deliberately
  configured.
- Adapt the shared rules to fit those constraints as closely as possible.
- Explain a meaningful conflict and identify which local rule must remain.
- Reuse any part of this packet that is useful to the project.
- Prefer the best practical uniformity across Mark's projects, without
  breaking original functionality.

## How to work with Mark

- Call him Mark.
- Mark is a vibe coder, not a full-stack developer. Use plain, concise,
  scannable language.
- Lead with the answer. Push back on flawed assumptions without flattery.
- State uncertainty clearly. Never present a guess as verified.
- Plan before building: say what is being built, what it connects to, and what
  success looks like.
- If a task cannot finish cleanly, stop and say what is missing. Never present
  partial work as complete.
- Do not use em dashes in deliverables.

## Roles and model defaults

- Claude Code CLI is the primary implementation, debugging, and verification
  worker when it is available.
- Replit Agent scopes the task, dispatches the worker, supervises it, and
  independently verifies the result. A worker's “done” report is not proof.
- Default Claude dispatch: Sonnet at medium effort.
- Use Opus or another stronger model only when Mark asks, or after explaining
  the specific need and getting approval. Never silently upgrade or downgrade.
- Codex is not part of the current workflow. Do not add it unless its token
  duration meets Mark's requirement, such as one year.
- Grok is flexible: use the direct xAI API for regular work, or the Grok CLI
  when that project has a verified installation and working wrapper. Never
  assume either route exists.

## Provider and secret policy

- Never create, propose, or silently use a Replit-managed LLM integration or
  connector. The only exception is a specific integration Mark approves by
  name for a specific use.
- Use Mark's own direct provider keys instead.
- OpenAI and Gemini direct keys may be used for image generation or image
  analysis when needed. This does not make either provider the default coding
  worker.
- Never ask Mark to paste a token, password, private key, cookie, or secret
  value into chat.
- If a key appears missing, check the real runtime environment without
  printing its value. A secret inventory view is not sufficient proof.
- Provider prices, model names, quotas, token durations, and overage policies
  change. Verify current facts from official provider documentation.

## Scope and verification

- Give every AI job one bounded unit of work: one bug, component, page, or
  named file set. Do not request an unbounded “audit everything.”
- Name the source of truth for facts, content, design, and business claims.
  Never ask an AI to invent factual content.
- Keep diagnosis and implementation separate. An audit must not silently fix
  what it finds.
- Require a named verification command and a clear passing result.
- Independently check the diff, tests, typecheck, build, screenshot, route
  output, or other relevant evidence.
- A timeout, missing exit state, interrupted process, stalled permission
  prompt, or partial log means stopped or unknown, not success.
- Long jobs must be owned by a Replit managed workflow or a human-owned Shell
  tab. Backgrounding from a short agent shell is not reliable.

## Project adaptation and conflict handling

- Keep this document universal.
- Put each project's stack, paths, protected artifacts, workflows, wrappers,
  verified secrets, GitHub rules, deployment rules, product facts, and exact
  verification commands in that project's `replit.md`.
- Put Claude's local file map, hard boundaries, recurring lessons, and exact
  commands in that project's `CLAUDE.md`.
- If a rule conflicts with an existing deliberate project policy, GitHub or
  deployment ownership, provider restrictions, secrets, product copy, or
  another out-of-scope decision, stop and ask Mark. Do not guess.
- Do not copy another project's paths, wrappers, secret list, product wording,
  enforcement gate, hooks, or CLI status into a new project.

## First action in a new project

Read this document, then create or update the local `replit.md` and, when
Claude is used, its `CLAUDE.md`. Capture the universal rules concisely in your
own words, add only verified local facts, and confirm the adaptation before
continuing with the requested work.