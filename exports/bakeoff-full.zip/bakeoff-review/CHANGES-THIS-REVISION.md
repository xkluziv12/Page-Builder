# Changes this revision — "dead-simple URL + GMB input"

The goal of the latest change set: make the bake-off's input DEAD-SIMPLE — just a
target URL + a verified GMB block — and fix the correctness bugs that would
otherwise make such a run silently wrong. The faithful old No-GMB VA reproduction
stays available but is no longer the primary path.

Hard rules held throughout: fail loud; never invent GMB data; NO per-model
special-casing; the No-GMB prompts stay BYTE-IDENTICAL when no GMB block is
supplied.

## What changed (by area)

1. **Thread the real target URL through the prompts** (was the core bug).
   - `promptVars` (duplicated in `conversation.ts` and `cost.ts`) used to rebuild
     `url` from `${baseDomain}/${city}-${state}` and IGNORE the supplied URL — so
     handing the harness a real URL did nothing.
   - Signature is now `promptVars(ctx, pageUrl?, gmb?)`: a non-empty `pageUrl` is
     used verbatim; otherwise it falls back to the derived slug (preserves the
     Billings default + the no-gmb path).
   - `pageUrl` + `gmb` are threaded through `ConversationDeps`, `RoutedDeps`,
     `EstimateCostArgs` and every caller (`run.ts`, `produce.ts`, `routed.ts`).

2. **Treat the supplied GMB block as the real, verified input** (`gmb.ts`).
   - `gmbContextSuffix` reworded: it now presents the block as the VERIFIED Google
     Business Profile the model MUST use for NAP/hours/CID/map. Removed the old
     "experimental / illustrative / not verified" language.
   - `BILLINGS_GMB` is now clearly the built-in SAMPLE target (reserved-fictional
     555-01xx phone + placeholder CID/street), with fail-loud validation in
     `resolveGmbProfile` for any real target.
   - Added `promptGmbFrom(GmbProfile): PromptGmb` so run + produce map a profile
     the same way.

3. **GMB-aware build/seo/verify prompts** (`miniPrompts.ts`).
   - Previously the build/seo/seo-verify prompts were hardcoded No-GMB even in the
     GMB scenario — they told the model "this city has no Google listing / use the
     HQ line / do not add a local address" while simultaneously handing it a real
     local phone+address. The two directly contradicted.
   - Now each prompt is `v.gmb ? <gmb text> : <verbatim old No-GMB text>`. With a
     GMB block the prompt instructs the model to USE the supplied NAP; without one,
     the prompt is byte-identical to before (verified against the git diff — the
     `else` side of every ternary is the exact prior string).
   - `PromptGmb` interface + `PromptVars.gmb` added.

4. **One dead-simple entry point + docs** (`scripts/package.json`, `replit.md`).
   - New `bakeoff:compare` script defaults `BAKEOFF_SCENARIOS=gmb` and reads
     `BAKEOFF_TARGET_URL` + `BAKEOFF_GMB_JSON`. The faithful path stays reachable
     via `BAKEOFF_SCENARIOS=no-gmb`.
   - A non-Billings target with no `BAKEOFF_GMB_JSON` fails loud with the exact
     JSON shape to provide (reuses `resolveGmbProfile`'s error text).

5. **Correctness bug fixes** (all uniform across models).
   - **Null-verdict gate** (`conversation.ts` + `routed.ts`): a verify turn with no
     ✅/❌ line used to count as a SILENT non-blocking pass. The loop is now
     `while (verdict !== "passed" && fixes < cap)` and FAILS LOUD if it never
     reaches an explicit PASS.
   - **routed validator**: the routed pipeline's `validate: () => {}` never detected
     a refusal/empty output, so the backup never triggered. It now uses
     `assertNotRefusal`, so an empty/refusal main response hands off to the backup.
   - **Poll-loop AbortSignal** (`providers.ts`): the OpenAI background-poll loop and
     the Grok web-search poll loop kept polling/billing after the surrounding
     `withTimeout` rejected. `withTimeout` now owns an `AbortController`; both loops
     thread the signal into `responses.create`/`responses.retrieve` and sleep via
     `abortableSleep`, so a timeout cancels the in-flight poll. Success path
     unchanged; Claude/Gemini ignore the optional signal.

6. **Honest scoring axes** (`score.ts`).
   - WordCount now has a CEILING penalty (overshoot scaled by `ceiling/wordCount`),
     symmetric to the existing floor — a model can no longer win by blowing past
     the mandated max.
   - **Speed pulled out of the quality composite** (still reported as its own axis)
     so a freakishly fast model can't mathematically dominate quality.
   - Reduced the combined `htmlMatch + visualMatch` weight (~0.40 → 0.25) so
     copying the reference template doesn't dominate a genuinely better page.
   - Final weights sum to exactly 1.0; documented in the `WEIGHTS` comment.

## Validation performed

- `pnpm run typecheck` (libs + all artifacts incl. the viewer) — green.
- `pnpm --filter @workspace/bake-off run typecheck` — green.
- 47 bake-off unit tests pass (`gmb.test.ts`, `conversation.test.ts`,
  `extract.test.ts`).
- **No live LLM sweep was run** — that costs money and needs a real URL + GMB from
  the operator. The wiring was verified via typecheck + unit tests only.

## A reviewer note on the prior automated review

An automated architect review flagged a "blocking" No-GMB byte-identity
regression. That was traced to a FALSE POSITIVE: the HQ-phone-in-No-GMB behavior
is pre-existing baseline (it predates this change set), and the git diff shows the
No-GMB branches preserved verbatim inside the new ternaries. Worth re-confirming
independently — diff the no-gmb prompt output before/after to verify byte-identity.
