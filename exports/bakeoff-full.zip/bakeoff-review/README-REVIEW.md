# Bake-Off — full review package

This is the complete **multi-LLM bake-off** for STS / Page Terminal ("M.A.R.K."),
packaged for an independent start-to-finish review. It contains the harness, the
results viewer, the shared library the harness depends on, and the supporting
docs. Nothing here needs the rest of the monorepo to be understood.

> **Note:** this is an *out-of-tree research harness* that drives the production
> page-building pipeline across several LLMs. It is NOT the shipped product. The
> shipped pipeline is `mc-core` (included under `mc-core/`); the harness reuses
> its prompts/registry/checkers so the comparison is faithful to production.

## What the bake-off does (in one paragraph)

It takes ONE target page (a city landing page) and has multiple LLMs each build
it through the EXACT phase pipeline a human VA follows — intro → build → design
gate / rebuild → SEO audit → SEO verification → schema → link verification —
then scores the results so you can compare models apples-to-apples. The only
controlled variable is the model: every model gets byte-identical prompts, the
same inlined fixtures, and the same shared research grounding.

There are two **scenarios**:
- **no-gmb** — the faithful reproduction of the VA's "no Google Business listing"
  checklist (HQ phone as backup; no local address/CID invented).
- **gmb** — the NEW dead-simple primary flow: hand every model a target URL + a
  *verified* Google Business Profile block, and they build the page with its real
  local NAP (name/address/phone), hours, CID, and map link.

And two **production modes** (layered on top of the comparison; they produce a
real page rather than score a comparison):
- **single** — one chosen model runs every phase via the stateful chat.
- **routed** — a main model per phase + an automatic GPT-5.4 backup on failure.

## Directory map

```
README-REVIEW.md          ← you are here
CHANGES-THIS-REVISION.md   ← what the most recent change set did (read this 2nd)
harness/                   ← the bake-off itself (scripts/src/bakeoff)
viewer/                    ← the React results viewer (artifacts/bake-off)
mc-core/                   ← the shared production lib the harness imports
context/                   ← package.json scripts, replit.md, memory doc
```

## Suggested reading order (start to finish)

The pipeline is a single growing conversation per (scenario, model). Follow it in
this order:

1. **`harness/target.ts`** — resolves the target page (URL → city/state/niche/
   pageType). Entry inputs: `BAKEOFF_TARGET_URL`.
2. **`harness/gmb.ts`** — the GMB scenario input: `resolveGmbProfile` (fail-loud
   validation, never invents data), `gmbContextSuffix` (the verified-NAP block
   handed to the model), `promptGmbFrom` (projects the full profile to the subset
   the prompts consume).
3. **`harness/miniPrompts.ts`** — the VERBATIM per-phase "mini prompts" a VA pastes
   at each step. This is the heart of fidelity. Note the GMB-awareness pattern:
   `v.gmb ? <gmb text> : <verbatim no-gmb text>` — the no-gmb branch is byte-
   identical to the original tool prompt.
4. **`harness/grounding.ts`** — the ONE shared research grounding authored once and
   inlined identically into every model's run.
5. **`harness/conversation.ts`** — the stateful single-model pipeline: intro →
   build → design gate → SEO → SEO-verify → schema → link-verify. Contains the
   verdict gate (`runVerification`, `readVerdict`) and the refusal guards
   (`assertNotRefusal`, `assertIntroNotBlocked`).
6. **`harness/routed.ts`** — the store-and-handoff multi-model pipeline (different
   models can't share one chat) with the structural backup-failover.
7. **`harness/providers.ts`** — the LLM adapters (Claude / Gemini / OpenAI / Grok),
   the timeout + abort wiring (`withTimeout`, `abortableSleep`), background-poll
   mode for OpenAI "pro", and live-web-search enforcement (`enforceLiveFetch`).
8. **`harness/run.ts`** — the comparison entry point (runs all models per scenario,
   in parallel, resumable; writes `results.json`).
9. **`harness/produce.ts`** + **`harness/routing.ts`** — the single/routed
   production modes (write `produce.json`).
10. **`harness/score.ts`** + **`harness/visual.ts`** + **`harness/rescore-visual.ts`**
    — scoring axes (structure / audit / schema / wordcount / html+visual match;
    speed is reported but NOT in the composite) and the visual judge.
11. **`harness/extract.ts`**, **`designGate.ts`**, **`fixtures.ts`**, **`cost.ts`**,
    **`types.ts`** — supporting: HTML/JSON extraction, the Joomla loadposition
    design gate, fixture loading (fail-loud), cost estimation, shared types.
12. **`viewer/src/`** — how the results are presented (datasets: current run +
    archived "Old Bake-Off" + the "Produced Page").

## Hard design rules the reviewer should hold the code to

1. **Apples-to-apples — never special-case a model's prompt.** Any per-model
   handling must be transport-only (an adapter detail), never a prompt change.
2. **The faithful no-gmb path stays byte-identical** when no GMB block is
   supplied. GMB-awareness is only ADDED as ternary branches.
3. **Fail loud, never silently degrade.** Missing GMB fields, an empty/refusal
   model response, or a verify turn with no explicit ✅ PASS must throw, not
   quietly pass. Never invent a CID / address / phone for a real page.
4. **A model that refuses/fails is a genuine finding**, recorded as an ERROR and
   isolated per model — never "rescued" by coaxing.

## Known caveats / open questions for the reviewer

- **Cost is RECONSTRUCTED, not captured** (`cost.ts`): providers' token usage is
  discarded; cost is an estimate that replays the turn sequence. Hidden reasoning
  tokens are under-counted; provider per-search fees are not included.
- **Leaderboard numbers are volatile** — model nondeterminism + the visual judge
  shift them every run. Treat any `results.json` as a snapshot, not truth.
- **The harness intentionally duplicates** `promptVars` (in `conversation.ts` and
  `cost.ts`) and the model constants (in `routing.ts`) — `run.ts` runs `main()` on
  import, so it must never be imported. These duplications must stay in lockstep.
- The viewer's `public/` and the harness `archive/` contain rendered screenshots
  and saved HTML from prior runs — included so you can see real output, but they
  are run artifacts, not source.

See `CHANGES-THIS-REVISION.md` for exactly what the latest change set modified and
why (the recent "dead-simple URL + GMB input" work).
